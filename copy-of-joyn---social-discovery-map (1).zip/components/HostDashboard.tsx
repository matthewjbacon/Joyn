import React, { useState, useMemo } from 'react';
import { User, Review, DropInCircle } from '../types';
import { ChevronLeftIcon } from './common/AppIcons';
import { Icon } from './common/Icon';

interface HostDashboardProps {
  user: User;
  users: User[];
  circles: DropInCircle[];
  onClose: () => void;
}

const StarRating: React.FC<{ rating: number, className?: string }> = ({ rating, className }) => (
    <div className={`flex gap-0.5 ${className}`}>
        {[...Array(5)].map((_, i) => (
            <Icon key={i} size={16} className={i < rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'} fill="currentColor">
                <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
            </Icon>
        ))}
    </div>
);


const HostDashboard: React.FC<HostDashboardProps> = ({ user, users, circles, onClose }) => {
  const [activeTab, setActiveTab] = useState<'reviews' | 'events'>('reviews');

  const averageRating = useMemo(() => {
    if (!user.reviews || user.reviews.length === 0) return 0;
    const total = user.reviews.reduce((sum, review) => sum + review.rating, 0);
    return total / user.reviews.length;
  }, [user.reviews]);
  
  const hostedCircles = useMemo(() => {
    return circles.filter(c => c.hostId === user.id).sort((a,b) => b.startTime.getTime() - a.startTime.getTime());
  }, [circles, user.id]);

  const findUserById = (id: string) => users.find(u => u.id === id);

  return (
    <div className="bg-gray-50 dark:bg-gray-950 flex flex-col h-full">
      <header className="p-4 flex items-center border-b border-gray-200 dark:border-gray-800">
        <button onClick={onClose} className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100 mr-4">
          <ChevronLeftIcon />
        </button>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">Host Dashboard</h1>
      </header>
      
      <div className="p-2 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800">
        <div className="grid grid-cols-2 gap-2 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
          <button onClick={() => setActiveTab('reviews')} className={`py-2 text-sm font-bold rounded-lg transition-colors ${activeTab === 'reviews' ? 'bg-white dark:bg-gray-700 shadow text-purple-600' : 'text-gray-600 dark:text-gray-300'}`}>
            Reviews
          </button>
          <button onClick={() => setActiveTab('events')} className={`py-2 text-sm font-bold rounded-lg transition-colors ${activeTab === 'events' ? 'bg-white dark:bg-gray-700 shadow text-purple-600' : 'text-gray-600 dark:text-gray-300'}`}>
            My Events
          </button>
        </div>
      </div>
      
      <div className="flex-grow overflow-y-auto p-6">
        {activeTab === 'reviews' && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm text-center">
              <p className="text-sm text-gray-500 dark:text-gray-400">Average Rating</p>
              <div className="flex items-center justify-center gap-2 mt-1">
                <p className="text-3xl font-bold text-gray-800 dark:text-gray-200">{averageRating.toFixed(1)}</p>
                <StarRating rating={averageRating} />
              </div>
              <p className="text-xs text-gray-400 mt-1">from {user.reviews.length} reviews</p>
            </div>
            
            <div className="space-y-4">
              {user.reviews.length > 0 ? user.reviews.map(review => {
                  const author = findUserById(review.authorId);
                  return (
                      <div key={review.id} className="bg-white dark:bg-gray-900 p-4 rounded-xl shadow-sm">
                          <div className="flex justify-between items-center mb-2">
                              <div className="flex items-center gap-2">
                                  <img src={author?.avatarUrl} alt={author?.alias} className="w-8 h-8 rounded-full" />
                                  <p className="font-semibold text-sm text-gray-800 dark:text-gray-200">{author?.alias || 'A Joyner'}</p>
                              </div>
                              <StarRating rating={review.rating} />
                          </div>
                          <p className="text-gray-600 dark:text-gray-300 text-sm">{review.text}</p>
                      </div>
                  )
              }) : (
                <div className="text-center py-10 bg-white dark:bg-gray-900 rounded-2xl">
                    <p className="text-gray-500 dark:text-gray-400">No reviews yet.</p>
                    <p className="text-sm text-gray-400 mt-1">Host a paid event to start getting feedback!</p>
                </div>
              )}
            </div>
          </div>
        )}
        
        {activeTab === 'events' && (
          <div className="space-y-4 animate-fade-in">
             {hostedCircles.map(circle => (
                 <div key={circle.id} className="bg-white dark:bg-gray-900 p-4 rounded-xl shadow-sm">
                     <h3 className="font-bold text-gray-800 dark:text-gray-200">{circle.name}</h3>
                     <p className="text-sm text-gray-500 dark:text-gray-400">{circle.startTime.toLocaleDateString()}</p>
                     <p className="text-sm text-teal-600 font-semibold mt-1">
                        {circle.joynPay?.isPaid ? `$${circle.joynPay.price.toFixed(2)}` : 'Free'}
                     </p>
                     <div className="flex items-center gap-2 mt-2">
                        <Icon size={16}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></Icon>
                        <span className="text-sm font-medium text-gray-600 dark:text-gray-400">{circle.userIds.length} participants</span>
                     </div>
                 </div>
             ))}
             {hostedCircles.length === 0 && (
                <div className="text-center py-10 bg-white dark:bg-gray-900 rounded-2xl">
                    <p className="text-gray-500 dark:text-gray-400">You haven't hosted any events.</p>
                </div>
             )}
          </div>
        )}
      </div>
    </div>
  );
};

export default HostDashboard;

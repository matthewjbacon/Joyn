import React from 'react';
import { TrendingLocation } from '../types';

interface TrendingLocationsBarProps {
  locations: TrendingLocation[];
  onSelect: (location: TrendingLocation) => void;
}

const TrendingLocationsBar: React.FC<TrendingLocationsBarProps> = ({ locations, onSelect }) => {
  return (
    <div className="w-full">
      <div className="flex space-x-3 overflow-x-auto p-4 snap-x snap-mandatory no-scrollbar">
        {locations.map(location => (
          <div key={location.id} onClick={() => onSelect(location)}
            className="snap-start flex-shrink-0 w-48 bg-white/90 backdrop-blur-md rounded-2xl p-3 shadow-md border border-gray-200/50 cursor-pointer hover:shadow-lg transition-shadow transform hover:-translate-y-1">
            <img loading="lazy" src={location.imageUrl} alt={location.name} className="w-full h-20 object-cover rounded-xl mb-2" />
            <h4 className="font-bold text-gray-900 truncate text-sm">{location.name}</h4>
            <div className="flex justify-between items-center text-xs mt-1">
              <div className="flex items-center gap-1 text-gray-500">
                  {location.vibes.join(', ')}
              </div>
              <span className="font-semibold text-blue-600 bg-blue-100 px-2 py-0.5 rounded-full">{location.activeUsers}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrendingLocationsBar;
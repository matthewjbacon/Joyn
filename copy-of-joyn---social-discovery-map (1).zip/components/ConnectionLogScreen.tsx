import React from 'react';
import { ConnectionLogEntry } from '../types';
import { Icon } from './common/Icon';
import { ChevronLeftIcon, JoynPinIcon, MessageIcon } from './common/AppIcons';

interface ConnectionLogScreenProps {
  log: ConnectionLogEntry[];
  onClose: () => void;
}

const ConnectionLogScreen: React.FC<ConnectionLogScreenProps> = ({ log, onClose }) => {
  const timeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return "Just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  const getIconForType = (type: ConnectionLogEntry['type']) => {
    switch(type) {
      case 'Joyn': return <JoynPinIcon className="w-5 h-5"/>;
      case 'Joyn Note': return <MessageIcon className="w-5 h-5"/>;
      case 'Wave': return <span className="text-lg">👋</span>;
      case 'JoynLive': return <MessageIcon className="w-5 h-5 text-purple-500" />;
      default: return null;
    }
  }

  return (
    <div className="bg-gray-50 dark:bg-gray-950 p-6 flex flex-col h-full">
      <header className="flex items-center mb-6">
        <button onClick={onClose} className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100 mr-4">
          <ChevronLeftIcon/>
        </button>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">My Joyn Trail</h1>
      </header>
      
      <p className="text-gray-600 dark:text-gray-400 mb-6 -mt-2">Your private Joyn trail. Add personal notes to remember your journey.</p>
      
      <div className="flex-grow overflow-y-auto space-y-4 pr-2">
        {log.map(entry => (
          <div key={entry.id} className="bg-white dark:bg-gray-900 p-4 rounded-xl shadow-sm">
            <div className="flex justify-between items-start">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 flex-shrink-0 bg-indigo-100 dark:bg-indigo-900/50 rounded-full flex items-center justify-center text-indigo-600 dark:text-indigo-300">
                    {getIconForType(entry.type)}
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 dark:text-gray-200">{entry.title}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{entry.description}</p>
                </div>
              </div>
              <span className="text-xs text-gray-400 flex-shrink-0">{timeAgo(entry.timestamp)}</span>
            </div>
             {entry.note ? (
                <p className="mt-2 text-sm text-gray-600 dark:text-gray-400 italic bg-gray-50 dark:bg-gray-800 p-2 rounded-md ml-11">Note: {entry.note}</p>
             ) : (
                <button className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline mt-2 ml-11">Add a note</button>
             )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConnectionLogScreen;
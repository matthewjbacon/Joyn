import React from 'react';

interface WelcomeScreenProps {
  onSignUp: () => void;
  onLogin: (isGuest?: boolean) => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onSignUp, onLogin }) => {
  return (
    <div 
      className={`w-full h-full flex flex-col justify-between p-8 text-white relative overflow-hidden bg-gradient-to-br from-[#1D1F2F] via-[#432d69] to-[#7D4CDB] animate-fade-in`}
    >
      <div 
        className="absolute inset-0 bg-no-repeat"
        style={{
            backgroundImage: `radial-gradient(circle at 10% 20%, rgba(255, 92, 87, 0.3) 0%, transparent 25%),
                              radial-gradient(circle at 80% 90%, rgba(60, 214, 190, 0.3) 0%, transparent 25%)`,
            backgroundSize: '200% 200%',
            animation: 'glow-bg 20s ease-in-out infinite'
        }}
      ></div>

      <div className="relative z-10 flex-grow flex flex-col justify-center items-center text-center">
        <h1 className="text-5xl font-bold leading-tight mb-4">
          Welcome to Joyn
        </h1>
        <p className="text-xl font-medium text-gray-300">
          Where Locals & Travelers Find Their Vibe
        </p>
      </div>

      <div className="relative z-10 space-y-4">
        <button
          onClick={onSignUp}
          className="w-full bg-[#FF5C57] text-white font-bold text-lg py-4 rounded-xl hover:bg-[#ff4b44] transition-transform transform active:scale-95"
        >
          Sign Up with Email
        </button>
        <button
          onClick={() => onLogin()}
          className="w-full bg-white/10 border-2 border-white/30 text-white font-bold text-lg py-3.5 rounded-xl hover:bg-white/20 transition-colors"
        >
          Continue with Google
        </button>
        <div className="text-center">
            <button onClick={() => onLogin()} className="text-gray-300 hover:text-white transition-colors text-sm font-medium">
                Already have an account? <span className="font-bold underline">Log In</span>
            </button>
        </div>
      </div>
    </div>
  );
};

export default WelcomeScreen;
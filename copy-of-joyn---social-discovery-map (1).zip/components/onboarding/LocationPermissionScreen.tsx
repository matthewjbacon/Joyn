
import React from 'react';
import { JoynPinIcon } from '../common/AppIcons';

interface LocationPermissionScreenProps {
  onGrant: () => void;
}

const LocationPermissionScreen: React.FC<LocationPermissionScreenProps> = ({ onGrant }) => {
  return (
    <div className="w-full h-full flex flex-col p-8 bg-gray-50 dark:bg-gray-950 text-center justify-between animate-fade-in">
      <div></div>
      <div className="animate-fade-in">
        <div className="inline-block bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-300 p-5 rounded-full mb-6">
          <JoynPinIcon className="w-12 h-12" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">One last step</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2 text-lg">
          Joyn is all about what's happening around you. We need your location to show you nearby people and events.
        </p>
        <p className="text-xs text-gray-400 dark:text-gray-500 mt-4">We respect your privacy and never share your exact location without your permission.</p>
      </div>
      
      <button
        onClick={onGrant}
        className="w-full bg-[#7D4CDB] text-white font-bold text-lg py-4 rounded-xl hover:bg-[#6c3ac0] transition-colors"
      >
        Enable Location
      </button>
      <div></div>
    </div>
  );
};

export default LocationPermissionScreen;

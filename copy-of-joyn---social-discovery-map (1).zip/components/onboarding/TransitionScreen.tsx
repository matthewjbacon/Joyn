
import React, { useState, useEffect } from 'react';
import { JoynPinIcon } from '../common/AppIcons';

const loadingTexts = [
  "Finding your vibe...",
  "Tuning into local frequencies...",
  "Warming up the map...",
  "Dropping you in...",
];

const TransitionScreen: React.FC = () => {
  const [loadingText, setLoadingText] = useState(loadingTexts[0]);

  useEffect(() => {
    let i = 0;
    const interval = window.setInterval(() => {
      i = (i + 1) % loadingTexts.length;
      setLoadingText(loadingTexts[i]);
    }, 1500);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full h-full flex flex-col p-8 text-white text-center justify-center items-center relative overflow-hidden bg-gradient-to-br from-[#1D1F2F] via-[#432d69] to-[#7D4CDB]">
        <div 
          className="absolute inset-0 bg-no-repeat"
          style={{
              backgroundImage: `radial-gradient(circle at 10% 20%, rgba(255, 92, 87, 0.2) 0%, transparent 30%),
                                radial-gradient(circle at 80% 90%, rgba(60, 214, 190, 0.2) 0%, transparent 30%)`,
              backgroundSize: '200% 200%',
              animation: 'glow-bg 20s ease-in-out infinite'
          }}
        ></div>
        
        <div className="relative z-10 flex flex-col items-center justify-center">
            {/* Blinking Pin Animation */}
            <div className="relative w-24 h-24 flex items-center justify-center mb-8">
                {/* Outer pulse */}
                <div className="absolute w-full h-full rounded-full bg-purple-400 animate-pulse-soft"></div>
                {/* Inner pin */}
                <JoynPinIcon className="w-16 h-16 text-white" />
            </div>

            <p className="text-xl font-semibold text-gray-200 transition-opacity duration-500">{loadingText}</p>
        </div>
    </div>
  );
};

export default TransitionScreen;

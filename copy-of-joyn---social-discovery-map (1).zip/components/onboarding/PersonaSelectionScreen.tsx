import React, { useState } from 'react';
import { PERSONAS } from '../../constants';

interface PersonaSelectionScreenProps {
  onSelect: (personaId: string) => void;
}

const PersonaSelectionScreen: React.FC<PersonaSelectionScreenProps> = ({ onSelect }) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  return (
    <div className="w-full h-full flex flex-col p-6 bg-gray-50 dark:bg-gray-950 animate-fade-in justify-between">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mt-12">Choose your Persona</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">This helps us tailor your experience. You can change it later.</p>
      </div>

      <div className="flex-grow flex items-center">
        <div className="grid grid-cols-2 gap-4 w-full">
          {PERSONAS.map((persona) => (
            <button
              key={persona.id}
              onClick={() => setSelectedId(persona.id)}
              className={`p-4 rounded-2xl text-center transition-all border-2 flex flex-col items-center justify-center aspect-square ${
                selectedId === persona.id
                  ? 'border-[#7D4CDB] bg-purple-50 dark:bg-purple-900/50 shadow-lg scale-105'
                  : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600'
              }`}
            >
              <persona.Icon className="w-12 h-12 text-[#7D4CDB] mb-3" />
              <h3 className="font-bold text-gray-800 dark:text-gray-200">{persona.title}</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{persona.description}</p>
            </button>
          ))}
        </div>
      </div>
      
      <button
        onClick={() => onSelect(selectedId!)}
        disabled={!selectedId}
        className="w-full bg-[#7D4CDB] text-white font-bold text-lg py-4 rounded-xl hover:bg-[#6c3ac0] transition-colors disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
      >
        Next
      </button>
    </div>
  );
};

export default PersonaSelectionScreen;
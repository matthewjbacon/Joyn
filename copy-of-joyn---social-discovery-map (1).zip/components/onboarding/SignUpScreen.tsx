import React, { useState } from 'react';
import { ChevronLeftIcon } from '../common/AppIcons';

interface SignUpScreenProps {
  onSignUp: () => void;
  onNavigateToLogin: () => void;
}

const SignUpScreen: React.FC<SignUpScreenProps> = ({ onSignUp, onNavigateToLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSignUp = () => {
    if (!email || !password) {
      setError('Please fill in all fields.');
      return;
    }
    // Simple email validation
    if (!/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }
    setError('');
    onSignUp();
  };

  return (
    <div className="w-full h-full flex flex-col p-6 bg-gray-50 dark:bg-gray-950 animate-slide-in-right">
      <header className="flex-shrink-0">
        <button onClick={onNavigateToLogin} className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100">
          <ChevronLeftIcon />
        </button>
      </header>
      <div className="flex-grow flex flex-col justify-center">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Create your account</h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">Let's get you started on Joyn.</p>
        </div>
        <div className="space-y-4">
          <input
            type="email"
            placeholder="Email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-lg p-4 text-base focus:ring-2 focus:ring-[#7D4CDB] focus:border-[#7D4CDB] outline-none transition text-gray-900 dark:text-gray-100 placeholder:text-gray-400 dark:placeholder:text-gray-500"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-lg p-4 text-base focus:ring-2 focus:ring-[#7D4CDB] focus:border-[#7D4CDB] outline-none transition text-gray-900 dark:text-gray-100 placeholder:text-gray-400 dark:placeholder:text-gray-500"
          />
          {error && <p className="text-red-500 text-sm text-center">{error}</p>}
        </div>
      </div>
      <footer className="flex-shrink-0">
        <button
          onClick={handleSignUp}
          className="w-full bg-[#7D4CDB] text-white font-bold text-lg py-4 rounded-xl hover:bg-[#6c3ac0] transition-colors"
        >
          Create Account
        </button>
      </footer>
    </div>
  );
};

export default SignUpScreen;

import React, { useState, useRef } from 'react';
import { PlusIcon } from '../common/AppIcons';

interface CreateProfileScreenProps {
  onCreate: (alias: string, avatarUrl: string) => void;
}

const CreateProfileScreen: React.FC<CreateProfileScreenProps> = ({ onCreate }) => {
  const [alias, setAlias] = useState('');
  const [error, setError] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('https://i.pravatar.cc/150?u=new-user');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCreate = () => {
    if (alias.trim().length < 3) {
      setError('Username must be at least 3 characters long.');
      return;
    }
    setError('');
    onCreate(alias.trim(), avatarUrl);
  };

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      const previewUrl = URL.createObjectURL(file);
      setAvatarUrl(previewUrl);
    }
  };

  return (
    <div className="w-full h-full flex flex-col p-6 bg-gray-50 dark:bg-gray-950 animate-fade-in text-center justify-between">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mt-12">Create your profile</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">This is how others will see you on Joyn.</p>
      </div>

      <div className="space-y-8">
        <div 
          className="relative inline-block group cursor-pointer"
          onClick={handleAvatarClick}
          aria-label="Change profile picture"
        >
          <img src={avatarUrl} alt="Avatar" className="w-32 h-32 rounded-full border-4 border-white dark:border-gray-800 shadow-lg mx-auto object-cover" />
          <div className="absolute bottom-0 right-0 w-10 h-10 bg-purple-500 text-white rounded-full flex items-center justify-center border-4 border-white dark:border-gray-950 group-hover:bg-purple-600 transition-colors">
            <PlusIcon />
          </div>
        </div>
        <input 
          type="file"
          ref={fileInputRef}
          onChange={handleAvatarChange}
          accept="image/*"
          className="hidden"
          aria-hidden="true"
        />

        <div>
          <label htmlFor="username" className="sr-only">Username</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">@</span>
            <input
              id="username"
              type="text"
              value={alias}
              onChange={(e) => setAlias(e.target.value)}
              placeholder="username"
              className="w-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-lg p-4 pl-8 text-base focus:ring-2 focus:ring-[#7D4CDB] focus:border-[#7D4CDB] outline-none transition text-gray-900 dark:text-gray-100 placeholder:text-gray-400 dark:placeholder:text-gray-500"
              style={{ fontSize: '16px' }}
              maxLength={20}
            />
          </div>
          {error && <p className="text-red-500 text-sm text-center mt-2">{error}</p>}
        </div>
      </div>

      <button
        onClick={handleCreate}
        disabled={alias.trim().length < 3}
        className="w-full bg-[#7D4CDB] text-white font-bold text-lg py-4 rounded-xl hover:bg-[#6c3ac0] transition-colors disabled:bg-gray-400 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
      >
        Continue
      </button>
    </div>
  );
};

export default CreateProfileScreen;

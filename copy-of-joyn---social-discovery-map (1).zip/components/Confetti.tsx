import React from 'react';

const Confetti: React.FC = () => {
  const confettiCount = 50;
  const colors = ['#FF5C57', '#FFD94C', '#3CD6BE', '#5AC8FA', '#7D4CDB'];

  return (
    <div className="absolute inset-0 z-50 pointer-events-none overflow-hidden">
      {Array.from({ length: confettiCount }).map((_, i) => {
        const style = {
          left: `${Math.random() * 100}%`,
          backgroundColor: colors[Math.floor(Math.random() * colors.length)],
          width: `${Math.random() * 8 + 6}px`,
          height: `${Math.random() * 8 + 6}px`,
          animation: `confetti-fall ${Math.random() * 2 + 1}s linear ${Math.random() * 1}s forwards`,
          opacity: 0,
        };
        return <div key={i} className="absolute rounded-full" style={style}></div>;
      })}
    </div>
  );
};

export default Confetti;
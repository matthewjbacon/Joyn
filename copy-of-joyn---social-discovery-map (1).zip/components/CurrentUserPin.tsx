
import React from 'react';
import { User } from '../types';

const CurrentUserPin: React.FC<{ user: User }> = ({ user }) => {
  const { isGhostMode, isInstantMeet } = user;

  const showGlow = !isGhostMode;
  const glowColorClass = isInstantMeet ? 'bg-green-400' : 'bg-sky-400';
  const glowBlurColorClass = isInstantMeet ? 'bg-green-300/30' : 'bg-sky-300/30';

  return (
    <div className="relative cursor-default flex items-center justify-center w-16 h-16">
      {showGlow && (
        <>
          {/* Pulsing halo */}
          <div className={`absolute w-full h-full rounded-full ${glowColorClass} animate-pulse-soft`}></div>
          {/* Soft Glow */}
          <div className={`absolute w-full h-full rounded-full ${glowBlurColorClass} blur-md`}></div>
        </>
      )}
      {/* Avatar */}
      <img
        src={user.avatarUrl}
        alt="Your location"
        className="relative w-14 h-14 rounded-full border-4 border-white dark:border-gray-800 bg-white shadow-xl"
      />
    </div>
  );
};

export default React.memo(CurrentUserPin);

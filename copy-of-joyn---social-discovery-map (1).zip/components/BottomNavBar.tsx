import React from 'react';
import { View } from '../types';
import { MapIcon, DiscoveryIcon, MessageIcon, ProfileIcon, JoynPlusIcon } from './common/AppIcons';

interface BottomNavBarProps {
    activeView: View;
    onNavigate: (view: View) => void;
    onActionClick: () => void;
    isOffline: boolean;
    isVisible: boolean;
}

const NavButton: React.FC<{ children: React.ReactNode; onClick?: () => void; isActive?: boolean; label: string; isDisabled?: boolean, id?: string }> = ({ children, onClick, isActive, label, isDisabled, id }) => (
    <div id={id} className="relative group flex flex-col items-center">
        <button
            onClick={onClick}
            aria-label={label}
            disabled={isDisabled}
            className={`p-3 rounded-full transition-all duration-300 relative ${isActive ? 'text-[#7D4CDB]' : 'text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'} ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
            {children}
            {isActive && <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-[#7D4CDB] rounded-full animate-bounce-in"></div>}
        </button>
        <div className="absolute bottom-full mb-2 px-2 py-1 bg-gray-800 dark:bg-gray-700 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            {label}
        </div>
    </div>
);


const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeView, onNavigate, onActionClick, isOffline, isVisible }) => {
    return (
        <nav className={`absolute bottom-0 left-0 right-0 p-4 z-30 transition-transform duration-300 ease-in-out ${isVisible ? 'translate-y-0' : 'translate-y-full'}`}>
            <div className="max-w-sm mx-auto bg-white/80 dark:bg-gray-900/80 backdrop-blur-md rounded-3xl shadow-lg dark:shadow-2xl flex items-center justify-around p-2">
                <NavButton onClick={() => onNavigate('map')} isActive={activeView === 'map'} label="Map" isDisabled={isOffline}>
                    <MapIcon />
                </NavButton>
                <NavButton id="nav-discovery" onClick={() => onNavigate('discovery')} isActive={activeView === 'discovery'} label="Discovery" isDisabled={isOffline}>
                    <DiscoveryIcon />
                </NavButton>
                <div id="joyn-action-button" className="relative group flex flex-col items-center">
                    <button
                        onClick={onActionClick}
                        aria-label="Start a Joyn"
                        disabled={isOffline}
                        className={`transition-all duration-300 transform -translate-y-3 h-16 w-16 flex items-center justify-center rounded-full shadow-lg text-white ${isOffline ? 'bg-gray-400 dark:bg-gray-600 cursor-not-allowed' : 'bg-[#7D4CDB] hover:bg-[#6c3ac0] active:scale-95 animate-pulse-cta hover:scale-105'}`}>
                        <JoynPlusIcon className="w-6 h-6"/>
                    </button>
                     <div className="absolute bottom-full mb-2 px-2 py-1 bg-gray-800 dark:bg-gray-700 text-white text-xs rounded-md opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none -translate-y-3">
                        Start a Joyn
                    </div>
                </div>
                <NavButton onClick={() => onNavigate('inbox')} isActive={activeView === 'inbox'} label="Inbox" isDisabled={isOffline}>
                    <MessageIcon />
                </NavButton>
                <NavButton onClick={() => onNavigate('profile')} isActive={activeView === 'profile'} label="Profile" isDisabled={isOffline}>
                    <ProfileIcon />
                </NavButton>
            </div>
        </nav>
    );
}

export default BottomNavBar;
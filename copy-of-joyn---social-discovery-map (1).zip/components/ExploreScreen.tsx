
import React, { useState, useMemo } from 'react';
import { DropInCircle, JoynLiveUpdate, User, VibeTag, GooglePlace } from '../types';
import ActivityCard from './explore/ActivityCard';
import { JoynLiveStream } from './explore/JoynLiveStream';
import PulseScroller from './explore/PulseScroller';
import { SearchIcon, FilterIcon } from './common/AppIcons';
import FilterModal from './explore/FilterModal';
import WeatherCard from './explore/WeatherCard';

interface ExploreScreenProps {
  circles: DropInCircle[];
  liveUpdates: JoynLiveUpdate[];
  places: GooglePlace[];
  users: User[];
  currentUser: User;
  allVibeTags: VibeTag[];
  onUserClick: (user: User) => void;
  onCircleClick: (circle: DropInCircle) => void;
  onLiveUpdateClick: (liveUpdate: JoynLiveUpdate) => void;
  onPlaceClick: (place: GooglePlace) => void;
  onToggleSaveCircle: (circleId: string) => void;
}

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="space-y-3">
        <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 px-4">{title}</h2>
        {children}
    </div>
);


const ExploreScreen: React.FC<ExploreScreenProps> = (props) => {
    const { circles, liveUpdates, places, users, currentUser, allVibeTags, onUserClick, onCircleClick, onLiveUpdateClick, onPlaceClick, onToggleSaveCircle } = props;
    
    const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
    const [showAllEvents, setShowAllEvents] = useState(false);
    const [filters, setFilters] = useState<{ price: 'all' | 'paid'; vibe: string | null }>({
        price: 'all',
        vibe: null,
    });
    
    const MAX_INITIAL_EVENTS = 5;

    const pulseCircles = useMemo(() => {
        return circles.filter(c => c.isHot).sort((a, b) => a.startTime.getTime() - b.startTime.getTime());
    }, [circles]);

    const filteredCircles = useMemo(() => {
        let result = [...circles].sort((a, b) => {
            if (a.isHot && !b.isHot) return -1;
            if (!a.isHot && b.isHot) return 1;
            return new Date(a.startTime).getTime() - new Date(b.startTime).getTime();
        });
        
        if (filters.price === 'paid') {
            result = result.filter(c => c.joynPay?.isPaid);
        }
        
        if (filters.vibe) {
            result = result.filter(circle => circle.vibeTagIds?.includes(filters.vibe!));
        }

        return result;
    }, [circles, filters]);

    const displayedCircles = showAllEvents ? filteredCircles : filteredCircles.slice(0, MAX_INITIAL_EVENTS);

    return (
        <div className="h-full flex flex-col bg-gray-100 dark:bg-gray-950">
            {/* Header */}
            <header className="p-4 flex justify-between items-center bg-gray-100/80 dark:bg-gray-950/80 backdrop-blur-md sticky top-0 z-10 border-b border-gray-200 dark:border-gray-800">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Discovery</h1>
                <div className="flex items-center gap-2">
                    <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
                        <SearchIcon className="w-6 h-6 text-gray-600 dark:text-gray-300"/>
                    </button>
                    <button onClick={() => setIsFilterModalOpen(true)} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
                        <FilterIcon className="w-6 h-6 text-gray-600 dark:text-gray-300"/>
                    </button>
                </div>
            </header>
            
            <div className="flex-grow overflow-y-auto pb-24 overflow-x-hidden">
                 <div className="space-y-6 pt-4">
                    <div className="px-4">
                        <WeatherCard />
                    </div>

                    {pulseCircles.length > 0 && (
                        <Section title="🔥 Hot Joyns">
                            <PulseScroller circles={pulseCircles} users={users} onPulseClick={onCircleClick} />
                        </Section>
                    )}
                    
                    <Section title="Events to Joyn">
                        <div className="space-y-3 px-4">
                            {displayedCircles.map((circle, index) => (
                                <ActivityCard 
                                    key={circle.id}
                                    circle={circle}
                                    allVibeTags={allVibeTags}
                                    users={users}
                                    isSaved={currentUser.savedCircleIds?.includes(circle.id) ?? false}
                                    onToggleSave={() => onToggleSaveCircle(circle.id)}
                                    onClick={() => onCircleClick(circle)}
                                    index={index}
                                    isHostedByCurrentUser={circle.hostId === currentUser.id}
                                />
                            ))}
                        </div>
                        {filteredCircles.length > MAX_INITIAL_EVENTS && !showAllEvents && (
                            <div className="px-4 mt-3">
                                <button onClick={() => setShowAllEvents(true)} className="w-full bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-gray-200 font-bold py-3 rounded-xl hover:bg-gray-300 dark:hover:bg-gray-700 transition-colors">
                                    Show All ({filteredCircles.length})
                                </button>
                            </div>
                        )}
                    </Section>
                    
                    <Section title="JoynLive">
                        <div className="px-4">
                            <JoynLiveStream liveUpdates={liveUpdates} users={users} currentUser={currentUser} onLiveUpdateClick={onLiveUpdateClick} />
                        </div>
                    </Section>
                </div>
            </div>

            <FilterModal 
                isOpen={isFilterModalOpen}
                onClose={() => setIsFilterModalOpen(false)}
                filters={filters}
                onFilterChange={setFilters}
                allVibeTags={allVibeTags}
            />
        </div>
    );
};

export default ExploreScreen;

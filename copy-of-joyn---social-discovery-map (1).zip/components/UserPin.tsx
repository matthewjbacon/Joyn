
import React from 'react';
import { User, Role } from '../types';
import { ROLE_COLORS } from '../constants';
import { InstantMeetIcon } from './common/AppIcons';

interface UserPinProps {
  user: User;
  isCurrentUser?: boolean;
  onClick?: () => void;
}

const UserPin: React.FC<UserPinProps> = ({ user, onClick }) => {
  const roleStyle = ROLE_COLORS[user.role as Role];
  const pinColor = user.pin ? roleStyle.border.replace('border-', '').replace(/\[|\]/g, '') : '#a8a29e'; // Default to a neutral stone color

  // A subtle glow based on role color
  const glowStyle = {
    boxShadow: `0 0 18px 4px ${pinColor}60`, // Using hex alpha
  };

  return (
    <div
      className="group cursor-pointer w-14 h-14"
      onClick={onClick}
      title={`Joyn with ${user.alias}`}
    >
      <div className="relative flex items-center justify-center w-full h-full">
        {/* Soft Zone Glow */}
        <div
          className="absolute w-full h-full rounded-full bg-white/10 backdrop-blur-sm transition-all duration-300"
          style={glowStyle}
        ></div>

        {/* Outer Ring */}
        <div 
          className="absolute w-full h-full rounded-full transition-all"
          style={{ border: `2px solid ${pinColor}` }}
        ></div>
        
        {/* Pulsing element for active pins */}
        {user.pin && (
          <div 
            className="absolute w-full h-full rounded-full animate-ping opacity-50"
            style={{ backgroundColor: pinColor, animationDuration: '2.5s' }}
          ></div>
        )}

        {/* Avatar, smaller and centered */}
        <img
          src={user.avatarUrl}
          alt={user.alias}
          className="relative w-12 h-12 rounded-full bg-white shadow-md group-hover:scale-110 transition-transform p-0.5"
        />
        
        {/* Instant Meet Indicator */}
        {user.isInstantMeet && (
            <div className="absolute -bottom-1 -right-1 bg-yellow-400 text-gray-800 w-6 h-6 rounded-full border-2 border-white flex items-center justify-center shadow-md" title={`${user.alias} is ready to meet now!`}>
                <InstantMeetIcon className="w-3.5 h-3.5" />
            </div>
        )}
      </div>
    </div>
  );
};

export default React.memo(UserPin);

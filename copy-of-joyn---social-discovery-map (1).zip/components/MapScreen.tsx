
import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { User, JoynLiveUpdate, DropInCircle as DropInCircleType, UserDropIn, GooglePlace, VibeTag } from '../types';
import { Icon } from './common/Icon';
import { MOCK_CURRENT_USER_ID, MOCK_USERS, calculateDistance, VIBE_TAGS, obfuscateLocation } from '../constants';
import UserPin from './UserPin';
import DropInCircle from './DropInCircle';
import PlacePin from './PlacePin';
import CurrentUserPin from './CurrentUserPin';
import { RecenterIcon, GhostIcon, FilterIcon, PlusIcon, MinusIcon, InstantMeetIcon, SunIcon, MoonIcon } from './common/AppIcons';
import { MapFilters } from '../App';
import CustomMarker from './CustomMarker';
import JoynLivePin from './JoynLivePin';


// Declare the google object to pacify TypeScript for the Google Maps API
declare global {
  interface Window {
    google: any;
  }
}

const mapStyles = {
    dark: [
      { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
      { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
      { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
      {
        featureType: "administrative.locality",
        elementType: "labels.text.fill",
        stylers: [{ color: "#d59563" }],
      },
      {
        featureType: "poi",
        elementType: "labels.text.fill",
        stylers: [{ color: "#d59563" }],
      },
      {
        featureType: "poi.park",
        elementType: "geometry",
        stylers: [{ color: "#263c3f" }],
      },
      {
        featureType: "poi.park",
        elementType: "labels.text.fill",
        stylers: [{ color: "#6b9a76" }],
      },
      {
        featureType: "road",
        elementType: "geometry",
        stylers: [{ color: "#38414e" }],
      },
      {
        featureType: "road",
        elementType: "geometry.stroke",
        stylers: [{ color: "#212a37" }],
      },
      {
        featureType: "road",
        elementType: "labels.text.fill",
        stylers: [{ color: "#9ca5b3" }],
      },
      {
        featureType: "road.highway",
        elementType: "geometry",
        stylers: [{ color: "#746855" }],
      },
      {
        featureType: "road.highway",
        elementType: "geometry.stroke",
        stylers: [{ color: "#1f2835" }],
      },
      {
        featureType: "road.highway",
        elementType: "labels.text.fill",
        stylers: [{ color: "#f3d19c" }],
      },
      {
        featureType: "transit",
        elementType: "geometry",
        stylers: [{ color: "#2f3948" }],
      },
      {
        featureType: "transit.station",
        elementType: "labels.text.fill",
        stylers: [{ color: "#d59563" }],
      },
      {
        featureType: "water",
        elementType: "geometry",
        stylers: [{ color: "#17263c" }],
      },
      {
        featureType: "water",
        elementType: "labels.text.fill",
        stylers: [{ color: "#515c6d" }],
      },
      {
        featureType: "water",
        elementType: "labels.text.stroke",
        stylers: [{ color: "#17263c" }],
      },
    ],
    light: [] // Default Google Maps style
};

interface MapFiltersPanelProps {
    filters: MapFilters;
    onFilterChange: (newFilters: Partial<MapFilters>) => void;
    allVibeTags: VibeTag[];
    onClose: () => void;
}

const MapFiltersPanel: React.FC<MapFiltersPanelProps> = ({ filters, onFilterChange, allVibeTags, onClose }) => {
    return (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-full max-w-sm p-4 z-20 animate-slide-down">
            <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-md rounded-2xl shadow-lg p-4">
                <div className="flex justify-between items-center mb-3">
                    <h3 className="font-bold text-gray-800 dark:text-gray-200">Filter by Vibe</h3>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100">&times;</button>
                </div>
                <div className="flex flex-wrap gap-2">
                    <button onClick={() => onFilterChange({ vibe: null })} className={`px-3 py-1.5 rounded-full text-sm font-semibold border-2 transition-all ${!filters.vibe ? 'bg-purple-500 text-white border-purple-500' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-200 hover:border-gray-400 dark:hover:border-gray-400'}`}>
                        All Vibes
                    </button>
                    {allVibeTags.map(tag => (
                        <button key={tag.id} onClick={() => onFilterChange({ vibe: tag.id })} className={`px-3 py-1.5 rounded-full text-sm font-semibold flex items-center gap-1.5 border-2 transition-all ${filters.vibe === tag.id ? `${tag.color.bg} ${tag.color.text} border-current dark:bg-opacity-30 dark:text-opacity-90` : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-200 hover:border-gray-400 dark:hover:border-gray-400'}`}>
                            {tag.emoji}
                            <span>{tag.name}</span>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

interface MapScreenProps {
  users: User[];
  circles: DropInCircleType[];
  places: GooglePlace[];
  liveUpdates: JoynLiveUpdate[];
  currentUser: User;
  onUserClick: (user: User) => void;
  onCircleClick: (circle: DropInCircleType) => void;
  onPlaceClick: (place: GooglePlace) => void;
  onLiveUpdateClick: (liveUpdate: JoynLiveUpdate) => void;
  isGhostMode: boolean;
  onGhostModeToggle: () => void;
  onInstantMeetToggle: () => void;
  onMapReady: (position: {lat: number, lng: number}) => void;
  onMapInteraction: () => void;
  filters: MapFilters;
  onFilterChange: (newFilters: Partial<MapFilters>) => void;
  allVibeTags: VibeTag[];
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
}

export const MapScreen: React.FC<MapScreenProps> = ({ users, circles, places, liveUpdates, currentUser, onUserClick, onCircleClick, onPlaceClick, onLiveUpdateClick, isGhostMode, onGhostModeToggle, onInstantMeetToggle, onMapReady, onMapInteraction, filters, onFilterChange, allVibeTags, theme, onThemeToggle }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any | null>(null);
  const [userPosition, setUserPosition] = useState<{lat: number, lng: number} | null>(null);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const initialLocationSet = useRef(false);
  
  const userCircleRef = useRef<any | null>(null);
  
  // Initialize map and load libraries
  useEffect(() => {
    const initMap = async () => {
      if (mapRef.current && !map) {
        try {
          const { Map, Circle } = await window.google.maps.importLibrary("maps");
          await window.google.maps.importLibrary("places");
          await window.google.maps.importLibrary("marker");

          const gMap = new Map(mapRef.current, {
            center: { lat: 40.72, lng: -74.035 }, // Initial center
            zoom: 12, 
            disableDefaultUI: true,
            gestureHandling: 'greedy',
            mapTypeControl: false,
            styles: theme === 'dark' ? mapStyles.dark : mapStyles.light,
            tilt: 0,
          });
          
          setMap(gMap);
        } catch (error) {
          console.error("Error loading Google Maps libraries:", error);
        }
      }
    };
    
    const checkGoogle = () => {
      if (window.google?.maps?.importLibrary) {
        initMap();
      } else {
        setTimeout(checkGoogle, 100);
      }
    }
    checkGoogle();
    
  }, [mapRef, map, theme]);

  // Update map style on theme change
  useEffect(() => {
    if (map) {
        map.setOptions({ styles: theme === 'dark' ? mapStyles.dark : mapStyles.light });
    }
  }, [map, theme]);
  
  // Add map interaction listeners
  useEffect(() => {
    if (map) {
      const listeners = [
        map.addListener('dragstart', onMapInteraction),
        map.addListener('zoom_changed', onMapInteraction),
      ];
      
      return () => {
        listeners.forEach(listener => window.google.maps.event.removeListener(listener));
      };
    }
  }, [map, onMapInteraction]);

  const animateCamera = useCallback((gMap: any, target: { center: any, zoom: number, tilt: number, heading: number }, duration: number) => {
    if (!gMap) return;
    let start: number | null = null;
    const initialCamera = {
        center: gMap.getCenter(),
        zoom: gMap.getZoom(),
        tilt: gMap.getTilt(),
        heading: gMap.getHeading(),
    };

    const frame = (time: number) => {
        if (start === null) start = time;
        const elapsed = time - start;
        const progress = Math.min(elapsed / duration, 1);
        const easeOutProgress = 1 - Math.pow(1 - progress, 3);

        const newCenter = {
            lat: initialCamera.center.lat() + (target.center.lat - initialCamera.center.lat()) * easeOutProgress,
            lng: initialCamera.center.lng() + (target.center.lng - initialCamera.center.lng()) * easeOutProgress,
        };
        
        gMap.moveCamera({
            center: newCenter,
            zoom: initialCamera.zoom + (target.zoom - initialCamera.zoom) * easeOutProgress,
            tilt: initialCamera.tilt + (target.tilt - initialCamera.tilt) * easeOutProgress,
            heading: initialCamera.heading + (target.heading - initialCamera.heading) * easeOutProgress,
        });

        if (progress < 1) {
            requestAnimationFrame(frame);
        }
    };
    requestAnimationFrame(frame);
  }, []);

  // Get user location and animate camera ONCE on initial load
  useEffect(() => {
    if (map && !initialLocationSet.current && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          
          setUserPosition(pos);
          onMapReady(pos);
          
          animateCamera(map, { center: pos, zoom: 17, tilt: 0, heading: 0 }, 2000);
          initialLocationSet.current = true;
        },
        () => {
          console.warn("Geolocation permission denied or failed. Defaulting location.");
          const defaultPos = { lat: 40.72, lng: -74.035 };
          onMapReady(defaultPos);
          setUserPosition(defaultPos);
          animateCamera(map, { center: defaultPos, zoom: 14, tilt: 0, heading: 0 }, 2000);
          initialLocationSet.current = true;
        }
      );
    }
  }, [map, onMapReady, animateCamera]);

  // Update visibility circle whenever position or user settings change
  useEffect(() => {
    if (map && window.google?.maps?.Circle && userPosition) {
        const radiusInMeters = (currentUser.visibilityRadius || 1) * 1609.34;
        if (userCircleRef.current) {
            userCircleRef.current.setCenter(userPosition);
            userCircleRef.current.setRadius(radiusInMeters);
        } else {
            userCircleRef.current = new window.google.maps.Circle({
                strokeColor: "#5AC8FA",
                strokeOpacity: 0.3,
                strokeWeight: 1,
                fillColor: "#5AC8FA",
                fillOpacity: 0.1,
                map,
                center: userPosition,
                radius: radiusInMeters,
            });
        }
        userCircleRef.current.setVisible(!currentUser.isGhostMode);
    }
  }, [map, userPosition, currentUser]);


  const filteredUsers = useMemo(() => {
    if (!filters.vibe) return users;
    return users.filter(user => user.pin?.vibeTagIds?.includes(filters.vibe!));
  }, [users, filters]);

  const filteredCircles = useMemo(() => {
    if (!filters.vibe) return circles;
    return circles.filter(circle => circle.vibeTagIds?.includes(filters.vibe!));
  }, [circles, filters]);


  const handleRecenter = () => {
    if (map && userPosition) {
        animateCamera(map, { center: userPosition, zoom: 17, tilt: 0, heading: 0 }, 1000);
    }
  };
  
  const handleZoomIn = useCallback(() => {
    if (map) {
      map.setZoom(map.getZoom() + 1);
    }
  }, [map]);

  const handleZoomOut = useCallback(() => {
    if (map) {
      map.setZoom(map.getZoom() - 1);
    }
  }, [map]);


  return (
    <div className="relative w-full h-full overflow-hidden">
       <header className="absolute top-0 left-0 right-0 p-4 z-20 flex justify-between items-center">
        <div className="flex items-center gap-3">
            <button 
                onClick={handleRecenter}
                aria-label="Recenter map"
                className="w-11 h-11 rounded-full flex items-center justify-center shadow-md transition-colors bg-white/70 dark:bg-gray-800/70 backdrop-blur-md text-gray-600 dark:text-gray-200 hover:bg-white dark:hover:bg-gray-700">
                  <RecenterIcon className="w-6 h-6"/>
            </button>
            <button 
                onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
                aria-label="Toggle Filters"
                className={`w-11 h-11 rounded-full flex items-center justify-center shadow-md transition-colors ${isFilterPanelOpen || filters.vibe ? 'bg-purple-500 text-white' : 'bg-white/70 dark:bg-gray-800/70 backdrop-blur-md text-gray-600 dark:text-gray-200'}`}>
                  <FilterIcon className="w-6 h-6"/>
            </button>
        </div>
        <div className="flex items-center gap-3">
            <button 
                onClick={onThemeToggle}
                aria-label="Toggle Theme"
                className="w-11 h-11 rounded-full flex items-center justify-center shadow-md transition-colors bg-white/70 dark:bg-gray-800/70 backdrop-blur-md text-gray-600 dark:text-gray-200 hover:bg-white dark:hover:bg-gray-700">
                {theme === 'light' ? <MoonIcon className="w-6 h-6"/> : <SunIcon className="w-6 h-6"/>}
            </button>
            <button 
                onClick={onInstantMeetToggle}
                aria-label="Toggle Instant Meet"
                className={`w-11 h-11 rounded-full flex items-center justify-center shadow-md transition-colors ${currentUser.isInstantMeet ? 'bg-yellow-400 text-gray-800' : 'bg-white/70 dark:bg-gray-800/70 backdrop-blur-md text-gray-600 dark:text-gray-200'}`}>
                <InstantMeetIcon className="w-6 h-6"/>
            </button>
            <button 
                onClick={onGhostModeToggle}
                aria-label="Toggle Ghost Mode"
                className={`w-11 h-11 rounded-full flex items-center justify-center shadow-md transition-colors ${isGhostMode ? 'bg-[#7D4CDB] text-white' : 'bg-white/70 dark:bg-gray-800/70 backdrop-blur-md text-gray-600 dark:text-gray-200'}`}>
                <GhostIcon className="w-6 h-6"/>
            </button>
        </div>
      </header>
      
      {isFilterPanelOpen && <MapFiltersPanel filters={filters} onFilterChange={onFilterChange} allVibeTags={allVibeTags} onClose={() => setIsFilterPanelOpen(false)} />}
      
      <div ref={mapRef} className="w-full h-full" />
      
      {!map && (
        <div className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-gray-100 dark:bg-gray-900 gap-4 z-10">
            <div className="w-16 h-16 border-4 border-gray-200 dark:border-gray-700 border-t-purple-500 rounded-full animate-spin"></div>
            <p className="text-gray-500 dark:text-gray-400 font-semibold">Initializing Map...</p>
        </div>
      )}

      {/* Declarative Markers */}
      {map && (
        <>
            {/* Current User */}
            {userPosition && (
                <CustomMarker map={map} position={userPosition} zIndex={100}>
                    <CurrentUserPin user={currentUser} />
                </CustomMarker>
            )}

            {/* Other Users */}
            {filteredUsers.map(user => {
                if(user.id !== MOCK_CURRENT_USER_ID && user.pin && user.location) {
                    let position = user.location;
                    if (user.limitLocationAccuracy) {
                        position = obfuscateLocation(user.location, 0.5);
                    }
                    return (
                        <CustomMarker key={`user-${user.id}`} map={map} position={position} zIndex={10}>
                            <UserPin user={user} onClick={() => onUserClick(user)} />
                        </CustomMarker>
                    );
                }
                return null;
            })}

            {/* Circles */}
            {filteredCircles.map(circle => {
                if (circle.location) {
                    return (
                        <CustomMarker key={`circle-${circle.id}`} map={map} position={circle.location} zIndex={20}>
                            <DropInCircle circle={circle} onClick={() => onCircleClick(circle)} />
                        </CustomMarker>
                    );
                }
                return null;
            })}

             {/* Live Updates */}
            {liveUpdates.map(update => (
              <CustomMarker key={`live-update-${update.id}`} map={map} position={update.location} zIndex={5}>
                <JoynLivePin liveUpdate={update} onClick={() => onLiveUpdateClick(update)} />
              </CustomMarker>
            ))}

            {/* Places */}
            {places.map(place => {
                if (!place.location) return null;

                const nearbyUsersCount = users.filter(user => 
                    user.pin && user.location && calculateDistance(place.location!.lat, place.location!.lng, user.location.lat, user.location.lng) < 0.2
                ).length;
        
                const recentTalksCount = liveUpdates.filter(update => 
                    update.location && 
                    calculateDistance(place.location!.lat, place.location!.lng, update.location.lat, update.location.lng) < 0.2 &&
                    (Date.now() - new Date(update.timestamp).getTime()) < (24 * 60 * 60 * 1000)
                ).length;
        
                const isHot = nearbyUsersCount > 0 || recentTalksCount > 1;
                
                return (
                    <CustomMarker key={`place-${place.id}`} map={map} position={place.location} zIndex={1}>
                        <PlacePin place={place} isHot={isHot} onClick={() => onPlaceClick(place)} />
                    </CustomMarker>
                );
            })}
        </>
      )}

      {/* Zoom Controls */}
      <div className="absolute top-20 right-4 z-20 flex flex-col bg-white/70 dark:bg-gray-800/70 backdrop-blur-md rounded-full shadow-md overflow-hidden">
        <button onClick={handleZoomIn} aria-label="Zoom in" className="w-11 h-11 flex items-center justify-center text-gray-600 dark:text-gray-200 hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
            <PlusIcon className="w-6 h-6"/>
        </button>
        <div className="h-px bg-gray-400/50 dark:bg-gray-600/50 mx-2"></div>
        <button onClick={handleZoomOut} aria-label="Zoom out" className="w-11 h-11 flex items-center justify-center text-gray-600 dark:text-gray-200 hover:bg-white/50 dark:hover:bg-black/20 transition-colors">
            <MinusIcon className="w-6 h-6"/>
        </button>
      </div>
    </div>
  );
};

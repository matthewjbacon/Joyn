
import React, { useState, useEffect, useMemo } from 'react';
import { DropInCircle, User, VibeTag, JoynPayDetails } from '../types';
import { Icon } from './common/Icon';
import { VIBE_TAGS, calculateDistance, estimateTravelTime } from '../constants';
import PriceDisplay from './joynpay/PriceDisplay';
import { ChevronLeftIcon } from './common/AppIcons';

interface GroupJoynActivityScreenProps {
  circle: DropInCircle | null;
  users: User[];
  currentUser: User | null;
  isJoined: boolean;
  onJoin: () => void;
  onJoinPaid: (circle: DropInCircle) => void;
  onClose: () => void;
  onOpenChat: () => void;
  onWaveHost: (user: User) => void;
  isOffline: boolean;
  onAddReview: (hostId: string, rating: number, text: string) => void;
  onEndCircle: (circleId: string) => void;
}

const StarRatingInput: React.FC<{ rating: number; setRating: (rating: number) => void }> = ({ rating, setRating }) => {
    return (
        <div className="flex justify-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
                <button
                    key={star}
                    onClick={() => setRating(star)}
                    className="text-3xl text-gray-300 dark:text-gray-600 transition-colors"
                >
                    <span className={star <= rating ? 'text-yellow-400' : ''}>★</span>
                </button>
            ))}
        </div>
    );
};

export const GroupJoynActivityScreen: React.FC<GroupJoynActivityScreenProps> = ({ circle, users, currentUser, isJoined, onJoin, onJoinPaid, onClose, onOpenChat, onWaveHost, isOffline, onAddReview, onEndCircle }) => {
  const [countdown, setCountdown] = useState('');
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(0);
  const [reviewText, setReviewText] = useState('');

  useEffect(() => {
    if (!circle) return;
    const intervalId = setInterval(() => {
      const diff = circle.startTime.getTime() - new Date().getTime();
      if (diff <= 0) {
        setCountdown('Started!');
        setShowReviewForm(true);
        clearInterval(intervalId);
        return;
      }
      const h = Math.floor(diff / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);
      setCountdown(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`);
    }, 1000);
    return () => clearInterval(intervalId);
  }, [circle]);

  if (!circle || !currentUser) return null;
  
  const host = users.find(u => u.id === circle.hostId);
  if (!host) return null; // Should not happen with valid data

  const participants = users.filter(u => circle.userIds.includes(u.id));
  const circleVibeTags = circle.vibeTagIds?.map(id => VIBE_TAGS.find(tag => tag.id === id)).filter(Boolean) as VibeTag[];

  const handleReviewSubmit = () => {
    if (reviewRating > 0 && reviewText.trim()) {
      onAddReview(circle.hostId, reviewRating, reviewText.trim());
      // Optionally hide the form after submission
      setShowReviewForm(false); 
    }
  };
  
  const renderParticipantFooter = () => {
    if (isJoined) {
      return (
        <button
          onClick={onOpenChat}
          disabled={isOffline}
          className="w-full bg-[#3CD6BE] text-white font-bold py-4 rounded-xl hover:bg-teal-500 flex items-center justify-center gap-2 disabled:bg-gray-400 disabled:cursor-not-allowed">
          <Icon><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></Icon>
          Open Group Chat
        </button>
      );
    }
    if (circle.joynPay?.isPaid) {
      const { price, currency } = circle.joynPay;
      return (
        <button
          onClick={(e) => { e.stopPropagation(); onJoinPaid(circle); }}
          disabled={isOffline}
          className="w-full bg-[#FF5C57] text-white font-bold py-4 rounded-xl hover:bg-red-500 transition-all transform active:scale-95 flex items-center justify-center gap-2 disabled:bg-gray-400 disabled:cursor-not-allowed">
            Reserve My Spot - <PriceDisplay price={price} currency={currency} />
        </button>
      );
    }
    // Default case: free to join, not yet joined
    return (
        <button
          onClick={onJoin}
          disabled={isOffline}
          className="w-full bg-[#FF5C57] text-white font-bold py-4 rounded-xl hover:bg-red-500 transition-all transform active:scale-95 disabled:bg-gray-400 disabled:cursor-not-allowed">
          Joyn this Vibe
        </button>
    );
  };
  
  const renderHostFooter = () => (
    <div className="flex gap-3">
        <button
          onClick={onOpenChat}
          disabled={isOffline}
          className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold py-4 rounded-xl hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
        >
          Manage Chat
        </button>
        <button
            onClick={() => {
                onEndCircle(circle.id);
            }}
            disabled={isOffline}
            className="flex-1 bg-red-500 text-white font-bold py-4 rounded-xl hover:bg-red-600 transition-colors"
        >
          End Event
        </button>
    </div>
);


  return (
    <div className="bg-gray-50 dark:bg-gray-950 flex flex-col h-full">
      {/* Cover Image */}
      <div className="relative h-48 bg-gray-300 dark:bg-gray-700">
        {circle.coverImageUrl && <img src={circle.coverImageUrl} alt={circle.name} className="w-full h-full object-cover" />}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        <button onClick={onClose} className="absolute top-4 left-4 bg-black/30 backdrop-blur-sm text-white w-10 h-10 rounded-full flex items-center justify-center">
            <ChevronLeftIcon />
        </button>
        <div className="absolute bottom-4 left-4 text-white">
            <h2 className="text-2xl font-bold">{circle.name}</h2>
            <div className="flex items-center gap-2 text-sm">
                <Icon size={16}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></Icon>
                <span>Hosted by <span className="font-semibold">{host.alias}</span></span>
            </div>
        </div>
      </div>
      
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Description */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm p-4">
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{circle.description}</p>
        </div>
        
        {/* About the Host */}
        {host.bio && (
             <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm p-4">
                <h3 className="font-bold text-gray-800 dark:text-gray-200 mb-2">About the host</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{host.bio}</p>
            </div>
        )}

        {/* Countdown */}
        <div className="text-center">
            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-widest">Starts In</p>
            <p className="text-5xl font-bold text-[#7D4CDB] tracking-tighter">{countdown}</p>
        </div>

        {/* Participants */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm p-4">
            <h3 className="font-bold text-gray-800 dark:text-gray-200 mb-3">{participants.length} Joyner{participants.length !== 1 && 's'} going</h3>
            <div className="flex -space-x-3">
                {participants.slice(0, 7).map(p => (
                    <img key={p.id} src={p.avatarUrl} alt={p.alias} className="w-12 h-12 rounded-full border-4 border-white dark:border-gray-900 shadow-sm"/>
                ))}
                {participants.length > 7 && (
                    <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-sm font-bold text-gray-600 dark:text-gray-300 border-4 border-white dark:border-gray-900">
                        +{participants.length - 7}
                    </div>
                )}
            </div>
        </div>
        
        {/* Review Form */}
        {showReviewForm && isJoined && host.id !== currentUser.id && (
            <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm p-4 animate-fade-in">
                <h3 className="font-bold text-gray-800 dark:text-gray-200 mb-3 text-center">How was your experience?</h3>
                <div className="space-y-4">
                    <StarRatingInput rating={reviewRating} setRating={setReviewRating} />
                    <textarea
                        value={reviewText}
                        onChange={(e) => setReviewText(e.target.value)}
                        placeholder={`Leave a review for ${host.alias}...`}
                        rows={3}
                        className="w-full bg-gray-100 dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-lg p-3 text-base focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition resize-none"
                    />
                    <button
                        onClick={handleReviewSubmit}
                        disabled={!reviewRating || !reviewText.trim()}
                        className="w-full bg-purple-500 text-white font-bold py-3 rounded-xl hover:bg-purple-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                    >
                        Submit Review
                    </button>
                </div>
            </div>
        )}

        {/* Vibe Tags */}
        {circleVibeTags.length > 0 && (
          <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm p-4">
              <h3 className="font-bold text-gray-800 dark:text-gray-200 mb-3">Activity Vibe</h3>
              <div className="flex flex-wrap gap-2">
                  {circleVibeTags.map(tag => (
                      <span key={tag.id} className={`px-3 py-1.5 rounded-full text-sm font-medium flex items-center gap-1.5 ${tag.color.bg} ${tag.color.text} dark:bg-opacity-20 dark:text-opacity-90`}>
                          {tag.emoji} {tag.name}
                      </span>
                  ))}
              </div>
          </div>
        )}
        
        {/* Refund Policy */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm p-4">
            <h3 className="font-bold text-gray-800 dark:text-gray-200 mb-2">Refund Policy</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Free cancellation up to 2 hours before event start time.</p>
        </div>
      </div>

      {/* Footer Actions */}
      <footer className="p-4 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-t border-gray-200 dark:border-gray-700">
        {currentUser.id === host.id ? renderHostFooter() : (
            <div className="flex gap-3">
                {!isJoined && (
                  <button 
                      onClick={() => onWaveHost(host)}
                      disabled={isOffline}
                      className="w-16 h-16 bg-[#FFD94C] hover:bg-amber-300 text-gray-800 font-bold rounded-xl transition-all text-lg transform active:scale-95 flex items-center justify-center disabled:bg-gray-400 disabled:cursor-not-allowed"
                      aria-label="Send a Wave"
                  >
                    <span role="img" aria-label="wave" className="text-2xl">👋</span>
                  </button>
                )}
                <div className="flex-1">
                    {renderParticipantFooter()}
                </div>
            </div>
        )}
      </footer>
    </div>
  );
};
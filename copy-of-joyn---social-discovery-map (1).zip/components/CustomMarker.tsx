
import { useState, useLayoutEffect, useEffect } from 'react';
import { createPortal } from 'react-dom';

// This declaration is still useful for type hints within the component.
declare const google: any;

interface CustomMarkerProps {
  map: any; // google.maps.Map
  position: { lat: number, lng: number };
  children: React.ReactNode;
  zIndex?: number;
}

export const CustomMarker: React.FC<CustomMarkerProps> = ({ map, position, children, zIndex = 1 }) => {
  // Use 'any' for the state since the class is defined dynamically.
  const [overlay, setOverlay] = useState<any | null>(null);

  // useLayoutEffect ensures the DOM is updated synchronously, which is good for map overlays.
  useLayoutEffect(() => {
    // We only proceed if the map instance is available. This check also ensures
    // that `window.google` is loaded, as `map` depends on it.
    if (map && position) {

      // DEFINE THE CLASS INSIDE THE HOOK.
      // This prevents the "Cannot read property 'maps' of undefined" error by ensuring
      // this code only runs *after* the Google Maps script has loaded.
      class CustomGoogleMapsOverlay extends window.google.maps.OverlayView {
        private position: any;
        private container: HTMLDivElement;
        private portalContainer: HTMLDivElement;

        constructor(position: any, zIndex: number) {
          super();
          this.position = position;
          this.container = document.createElement('div');
          this.container.style.position = 'absolute';
          // Center the custom marker component on the exact coordinate
          this.container.style.transform = 'translate(-50%, -50%)'; 
          this.container.style.zIndex = `${zIndex}`;
          
          // This is the container where our React component will be portalled.
          this.portalContainer = document.createElement('div');
          this.container.appendChild(this.portalContainer);
        }

        // Standard OverlayView method: called when the overlay is added to the map.
        onAdd() {
          this.getPanes()?.floatPane?.appendChild(this.container);
        }
        
        // Standard OverlayView method: called when the overlay is removed from the map.
        onRemove() {
          if (this.container.parentElement) {
            this.container.parentElement.removeChild(this.container);
          }
        }

        // Standard OverlayView method: called when the map is panned or zoomed.
        draw() {
          const projection = this.getProjection();
          if (!projection || !this.position) return;
          const point = projection.fromLatLngToDivPixel(this.position);
          if (point) {
            this.container.style.left = `${point.x}px`;
            this.container.style.top = `${point.y}px`;
          }
        }

        // Custom method to update the position of the overlay.
        updatePosition(position: any) {
          this.position = position;
          this.draw();
        }
        
        // Custom method to get the portal container for React.
        getPortalContainer() {
          return this.portalContainer;
        }
      }

      const newOverlay = new CustomGoogleMapsOverlay(
        new window.google.maps.LatLng(position.lat, position.lng),
        zIndex || 1
      );
      
      newOverlay.setMap(map);
      setOverlay(newOverlay);

      // Cleanup function: remove the overlay from the map when the component unmounts.
      return () => {
        newOverlay.setMap(null);
      };
    }
    // Return an empty cleanup function if the map is not ready.
    return () => {};
  }, [map, zIndex]); // Effect dependencies: only re-run if map or zIndex changes.
  
  // This separate effect handles position updates efficiently without re-creating the overlay.
  useEffect(() => {
    if (overlay && position) {
      overlay.updatePosition(new window.google.maps.LatLng(position.lat, position.lng));
    }
  }, [position, overlay]);

  // If the overlay isn't created yet, render nothing.
  if (!overlay) return null;

  // Use a portal to render the React children into the container div of the overlay.
  // This is the correct way to bridge React's virtual DOM with the Google Maps API's DOM manipulation.
  return createPortal(children, overlay.getPortalContainer());
};

export default CustomMarker;

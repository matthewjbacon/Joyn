
import React, { useState, useEffect } from 'react';
import { User, UserDropIn, VibeTag, DropInPrefill, PresenceStatus, JoynPayDetails } from '../types';
import { PERSONAS, ROLE_COLORS, VIBE_TAGS, PRESENCE_OPTIONS } from '../constants';
import { Icon } from './common/Icon';
import UserPin from './UserPin';
import { CloseIcon, GhostIcon, JoynCoinIcon } from './common/AppIcons';
import PriceDisplay from './joynpay/PriceDisplay';

interface DropInFormData {
  presence: PresenceStatus;
  title: string;
  vibeTagIds: string[];
  duration: number; // in hours
  radius: number; // in miles
  isPaid: boolean;
  price: number;
  currency: 'USD' | 'joyncoin';
}

interface DropInFlowProps {
  currentUser: User;
  onDropIn: (data: Omit<UserDropIn, 'expiresAt'>, joynPay?: JoynPayDetails) => void;
  onCancel: () => void;
  isGhostMode: boolean;
  onGhostModeToggle: () => void;
  prefill?: DropInPrefill | null;
}

const DropInFlow: React.FC<DropInFlowProps> = ({ currentUser, onDropIn, onCancel, isGhostMode, onGhostModeToggle, prefill }) => {
  const [step, setStep] = useState(1);
  const [personaId, setPersonaId] = useState<string>(currentUser.personaId || 'explorer');
  
  const [formData, setFormData] = useState<DropInFormData>({
    presence: PresenceStatus.Available,
    title: prefill?.locationName ? `Joyning at ${prefill.locationName}` : '',
    vibeTagIds: [],
    duration: 3, // in hours
    radius: 1, // in miles
    isPaid: false,
    price: 10,
    currency: 'USD',
  });
  
  const handleFieldChange = (field: keyof typeof formData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleConfirm = () => {
    const { presence, title, duration, radius, vibeTagIds, isPaid, price, currency } = formData;
    const joynPayDetails: JoynPayDetails | undefined = isPaid ? { isPaid: true, price: Number(price), currency } : undefined;
    onDropIn({ presence, title, duration, radius, vibeTagIds }, joynPayDetails);
  };
  
  const toggleVibeTag = (tagId: string) => {
    handleFieldChange('vibeTagIds', 
      (formData.vibeTagIds as string[]).includes(tagId) 
        ? (formData.vibeTagIds as string[]).filter(id => id !== tagId) 
        : [...formData.vibeTagIds, tagId]
    );
  };
  
  const selectedPersona = PERSONAS.find(p => p.id === personaId)!;

  const Step1 = () => (
    <div className="space-y-6">
       {prefill?.locationName && (
        <div className="bg-purple-50 dark:bg-purple-900/50 border border-purple-200 dark:border-purple-800 text-purple-800 dark:text-purple-300 p-3 rounded-xl text-center text-sm">
            Creating a Joyn at: <span className="font-bold">{prefill.locationName}</span>
        </div>
      )}
      <div>
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">What's your presence?</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Let others know what you're open to right now.</p>
        <div className="grid grid-cols-2 gap-3">
          {PRESENCE_OPTIONS.map(p => (
            <button key={p.id} onClick={() => handleFieldChange('presence', p.id)}
              className={`p-4 rounded-2xl text-left transition-all border-2 flex items-start gap-3 ${formData.presence === p.id ? 'border-[#7D4CDB] bg-purple-50 dark:bg-purple-900/50' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-purple-300 dark:hover:border-purple-600'}`}>
              <span className="text-2xl mt-0.5">{p.emoji}</span>
              <div>
                <h3 className="font-bold text-gray-800 dark:text-gray-200">{p.title}</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">{p.description}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
       <div>
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">Add a title (optional)</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">e.g., "Grabbing coffee," "Working on my novel"</p>
        <input 
            type="text" 
            value={formData.title}
            onChange={(e) => handleFieldChange('title', e.target.value)}
            placeholder="What are you up to?"
            className="w-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-lg p-3 text-base focus:ring-2 focus:ring-[#7D4CDB] focus:border-[#7D4CDB] outline-none transition text-gray-800 dark:text-gray-200 placeholder:text-gray-400 dark:placeholder:text-gray-500"
            maxLength={100}
        />
        <div className="text-right text-xs text-gray-400 dark:text-gray-500 mt-1 pr-1">
            {formData.title.length} / 100
        </div>
      </div>
      <div>
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">What's the vibe?</h2>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">Pick a few tags that match your mood.</p>
        <div className="flex flex-wrap gap-2">
            {VIBE_TAGS.map(tag => (
                <button
                    key={tag.id}
                    onClick={() => toggleVibeTag(tag.id)}
                    className={`px-4 py-2 rounded-full text-sm font-semibold flex items-center gap-2 border-2 transition-all ${(formData.vibeTagIds as string[]).includes(tag.id) ? `${tag.color.bg} ${tag.color.text} border-current dark:bg-opacity-30 dark:text-opacity-90` : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-400 dark:hover:border-gray-500'}`}
                >
                    {tag.emoji}
                    <span>{tag.name}</span>
                </button>
            ))}
        </div>
      </div>
    </div>
  );

  const Step2 = () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-3">Set your visibility</h2>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border-2 border-gray-200 dark:border-gray-700 space-y-4">
            {/* Ghost Mode Toggle */}
            <div className="flex justify-between items-center bg-gray-50 dark:bg-gray-700/50 p-3 rounded-lg">
                <div className='flex items-center gap-3'>
                    <GhostIcon className="w-6 h-6 text-gray-500 dark:text-gray-400"/>
                    <div>
                        <label htmlFor="ghostMode" className="font-medium text-gray-800 dark:text-gray-200">Ghost Mode</label>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Go invisible while you set up.</p>
                    </div>
                </div>
                <button onClick={onGhostModeToggle} className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${isGhostMode ? 'bg-[#7D4CDB]' : 'bg-gray-300 dark:bg-gray-600'}`}>
                    <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isGhostMode ? 'translate-x-6' : 'translate-x-1'}`}/>
                </button>
            </div>

            <div className={isGhostMode ? 'opacity-50' : ''}>
                <div>
                    <label className="font-medium text-gray-800 dark:text-gray-200">Visibility Radius</label>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">How far you can be seen by others.</p>
                    <input type="range" min="0.5" max="5" step="0.5" value={formData.radius} onChange={e => handleFieldChange('radius', Number(e.target.value))}
                      disabled={isGhostMode} className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[#7D4CDB] disabled:bg-gray-300 dark:disabled:bg-gray-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 text-center font-medium">{isGhostMode ? 'Disabled' : `${formData.radius.toFixed(1)} miles`}</p>
                </div>
                 <div>
                    <label className="font-medium text-gray-800 dark:text-gray-200">Duration</label>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">How long your pin will be active.</p>
                    <input type="range" min="1" max="8" step="1" value={formData.duration} onChange={e => handleFieldChange('duration', Number(e.target.value))}
                      disabled={isGhostMode} className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[#7D4CDB] disabled:bg-gray-300 dark:disabled:bg-gray-600" />
                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 text-center font-medium">{isGhostMode ? 'Disabled' : `${formData.duration} ${formData.duration > 1 ? 'hours' : 'hour'}`}</p>
                </div>
            </div>
        </div>
      </div>
      {currentUser.isJoynPayActive && (
          <div>
            <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 mb-3">Monetize</h2>
            <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl border-2 border-gray-200 dark:border-gray-700 space-y-4">
               <div className="flex justify-between items-center bg-gray-50 dark:bg-gray-700/50 p-3 rounded-lg">
                  <div className='flex items-center gap-3'>
                      <JoynCoinIcon className="w-6 h-6 text-teal-500"/>
                      <div>
                          <label htmlFor="isPaid" className="font-medium text-gray-800 dark:text-gray-200">Monetize this Joyn</label>
                          <p className="text-sm text-gray-500 dark:text-gray-400">Charge an entry fee.</p>
                      </div>
                  </div>
                  <button onClick={() => handleFieldChange('isPaid', !formData.isPaid)} className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${formData.isPaid ? 'bg-teal-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
                      <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${formData.isPaid ? 'translate-x-6' : 'translate-x-1'}`}/>
                  </button>
              </div>
              {formData.isPaid && (
                <div className="space-y-4 pt-2 animate-fade-in">
                  <div>
                    <label className="font-medium text-gray-800 dark:text-gray-200">Ticket Price</label>
                     <div className="flex items-center gap-2 mt-1">
                        <input 
                            type="number"
                            value={formData.price}
                            onChange={(e) => handleFieldChange('price', Number(e.target.value))}
                            className="w-full bg-white dark:bg-gray-700 border-2 border-gray-200 dark:border-gray-600 rounded-lg p-3 text-base focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none transition"
                        />
                         <div className="flex items-center rounded-lg border-2 border-gray-200 dark:border-gray-600">
                           <button onClick={() => handleFieldChange('currency', 'joyncoin')} className={`px-3 py-3 rounded-l-md transition-colors ${formData.currency === 'joyncoin' ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-200' : 'bg-white dark:bg-gray-700'}`}><JoynCoinIcon className="w-5 h-5"/></button>
                           <button onClick={() => handleFieldChange('currency', 'USD')} className={`px-3 py-3 rounded-r-md transition-colors font-bold ${formData.currency === 'USD' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-200' : 'bg-white dark:bg-gray-700'}`}>$</button>
                         </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
    </div>
  );
  
  const Step3 = () => (
    <div>
        <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-gray-200 mb-2">Ready to Joyn?</h2>
        <p className="text-center text-gray-500 dark:text-gray-400 mb-6">Here's how you'll appear on the map. You can cancel your Joyn at any time from your profile.</p>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border-2 border-gray-200 dark:border-gray-700 relative">
          <div className="flex justify-center mb-6">
            <UserPin user={{...currentUser, pin: { presence: formData.presence, expiresAt: new Date(), radius: formData.radius, duration: formData.duration, vibeTagIds: formData.vibeTagIds as string[], joynPay: formData.isPaid ? {isPaid: true, price: Number(formData.price), currency: formData.currency} : undefined, title: formData.title } }} />
          </div>
          {formData.title && <p className="text-center font-bold text-xl text-gray-800 dark:text-gray-200">"{formData.title}"</p>}
          <div className="flex flex-wrap justify-center gap-2 mt-4">
              {(formData.vibeTagIds as string[]).map(id => VIBE_TAGS.find(t => t.id === id)).filter(Boolean).map(tag => (
                tag && <span key={tag.id} className={`px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1.5 ${tag.color.bg} ${tag.color.text} dark:bg-opacity-20 dark:text-opacity-90`}>
                  {tag.emoji} {tag.name}
                </span>
              ))}
          </div>
          {formData.isPaid && <div className="mt-4 text-center"><PriceDisplay price={formData.price} currency={formData.currency} className="text-2xl font-bold text-teal-600 dark:text-teal-400" /></div>}
        </div>
    </div>
  );

  return (
    <div className="bg-gray-50 dark:bg-gray-950 flex flex-col p-6 h-full">
      <header className="flex justify-between items-center mb-6 flex-shrink-0">
        <h1 className="text-xl font-bold text-gray-800 dark:text-gray-200">Start a Joyn ({step}/3)</h1>
        <button onClick={onCancel} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-800">
          <CloseIcon />
        </button>
      </header>

      <div className="flex-grow overflow-y-auto pr-2 -mr-2">
        {step === 1 && <Step1 />}
        {step === 2 && <Step2 />}
        {step === 3 && <Step3 />}
      </div>
      
      <footer className="mt-6 flex gap-3 flex-shrink-0">
        {step > 1 && (
          <button onClick={() => setStep(step - 1)} className="bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold py-4 rounded-xl flex-grow hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">
            Back
          </button>
        )}
        {step < 3 ? (
          <button onClick={() => setStep(step + 1)} className="bg-[#7D4CDB] text-white font-bold py-4 rounded-xl flex-grow hover:bg-[#6c3ac0] transition-colors">
            Next
          </button>
        ) : (
          <button onClick={handleConfirm} className="bg-teal-500 text-white font-bold py-4 rounded-xl flex-grow hover:bg-teal-600 transition-colors transform active:scale-95">
            Confirm & Joyn
          </button>
        )}
      </footer>
    </div>
  );
};

export default DropInFlow;
import React, { useState, useEffect } from 'react';
import { UserDropIn } from '../types';
import { Icon } from './common/Icon';

interface ActiveDropInBarProps {
  pin: UserDropIn;
  onEndJoyn: () => void;
}

const ActiveDropInBar: React.FC<ActiveDropInBarProps> = ({ pin, onEndJoyn }) => {
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    const calculateTimeLeft = () => {
      const diff = Math.max(0, pin.expiresAt.getTime() - new Date().getTime());
      const hours = String(Math.floor(diff / (1000 * 60 * 60))).padStart(2, '0');
      const minutes = String(Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))).padStart(2, '0');
      const seconds = String(Math.floor((diff % (1000 * 60)) / 1000)).padStart(2, '0');
      setTimeLeft(`${hours}:${minutes}:${seconds}`);
    };

    calculateTimeLeft();
    const intervalId = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(intervalId);
  }, [pin.expiresAt]);

  return (
    <div className="absolute bottom-24 left-1/2 -translate-x-1/2 w-full max-w-sm px-4 z-30 animate-slide-up-bounce" style={{animationDuration: '0.5s'}}>
        <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-md rounded-2xl shadow-lg p-3 flex items-center justify-between">
            <div className='flex items-center gap-3'>
                <div className="w-10 h-10 rounded-full bg-[#7D4CDB] text-white flex items-center justify-center">
                    <Icon className="animate-ping absolute h-3 w-3 opacity-75"><circle cx="12" cy="12" r="10" /></Icon>
                    <Icon className="relative"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></Icon>
                </div>
                <div>
                    <p className="font-bold text-gray-800 dark:text-gray-100">You're Joyning!</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Time left: {timeLeft}</p>
                </div>
            </div>
            <button onClick={onEndJoyn} className="text-gray-400 hover:text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50 p-2 rounded-full transition-colors" aria-label="End Joyn">
                 <Icon size={20}><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></Icon>
            </button>
        </div>
    </div>
  );
};

export default ActiveDropInBar;
import React, { useMemo } from 'react';
import { GooglePlace, User } from '../types';
import Modal from './common/Modal';
import { Icon } from './common/Icon';
import { calculateDistance, getPlaceStyle } from '../constants';

interface PlaceDetailModalProps {
  place: GooglePlace | null;
  currentUser: User | null;
  isOpen: boolean;
  onClose: () => void;
  onCreateDropIn: (place: GooglePlace) => void;
}

const PlaceDetailModal: React.FC<PlaceDetailModalProps> = ({ place, currentUser, isOpen, onClose, onCreateDropIn }) => {
  if (!place || !currentUser) return null;

  const distance = useMemo(() => {
    if (place.location && currentUser?.location) {
      return calculateDistance(currentUser.location.lat, currentUser.location.lng, place.location.lat, place.location.lng);
    }
    return null;
  }, [currentUser?.location, place.location]);

  const placeStyle = getPlaceStyle(place.types);
  const photoUrl = place.photos?.[0]?.uri || `https://via.placeholder.com/400x200/cccccc/888888?text=${encodeURIComponent(place.displayName)}`;

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    return (
      <div className="flex items-center text-amber-400">
        {[...Array(fullStars)].map((_, i) => <Icon key={`full-${i}`} size={16}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></Icon>)}
        {halfStar && <Icon size={16}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></Icon>}
        {[...Array(emptyStars)].map((_, i) => <Icon key={`empty-${i}`} size={16} className="text-gray-300"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></Icon>)}
      </div>
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} variant="bottom-sheet">
      <div className="bg-white rounded-t-2xl shadow-2xl overflow-hidden">
        {/* Image Header */}
        <div className="relative h-40 bg-gray-200">
          <img src={photoUrl} alt={place.displayName} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-4 left-4 text-white">
            <h2 className="text-2xl font-bold">{place.displayName}</h2>
            <p className="text-sm opacity-90 capitalize">{place.types?.[0]?.replace(/_/g, ' ')}</p>
          </div>
        </div>

        {/* Info Section */}
        <div className="p-4">
          <div className="flex justify-between items-center">
            {place.rating && (
              <div className="flex items-center gap-2">
                {renderStars(place.rating)}
                <span className="text-sm text-gray-500 font-semibold">{place.rating.toFixed(1)}</span>
                <span className="text-sm text-gray-400">({place.userRatingCount})</span>
              </div>
            )}
            {distance !== null && (
              <div className="text-sm font-bold text-gray-700 bg-gray-100 px-3 py-1.5 rounded-full">
                {distance.toFixed(1)} mi away
              </div>
            )}
          </div>
          <p className="text-gray-600 mt-2 text-sm">{place.formattedAddress}</p>
        </div>

        {/* Actions */}
        <div className="p-4 pt-2 pb-6 flex flex-col gap-3">
          <button
            onClick={() => onCreateDropIn(place)}
            className="w-full bg-[#FF5C57] text-white font-bold py-4 rounded-xl hover:bg-red-500 transition-all text-lg flex items-center justify-center gap-2 transform active:scale-95"
          >
            <Icon><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></Icon>
            Start a Joyn Here
          </button>
           <button
            onClick={onClose}
            className="w-full bg-gray-200 text-gray-800 font-bold py-3 rounded-xl hover:bg-gray-300 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </Modal>
  );
};

export default PlaceDetailModal;
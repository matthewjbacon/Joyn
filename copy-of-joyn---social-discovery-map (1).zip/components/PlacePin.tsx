

import React from 'react';
import { GooglePlace } from '../types';
import { getPlaceStyle } from '../constants';
import { Icon } from './common/Icon';
import { FireIcon } from './common/AppIcons';

interface PlacePinProps {
  place: GooglePlace;
  isHot?: boolean;
  onClick?: () => void;
}

const PlacePin: React.FC<PlacePinProps> = ({ place, isHot = false, onClick }) => {
  const style = getPlaceStyle(place.types);

  return (
    <div className="cursor-pointer group" onClick={onClick} title={isHot ? "Hot Spot — lots of activity here lately." : place.displayName}>
      <div className="relative flex items-center justify-center">
        {/* Pulse animation for 'hot' places */}
        {isHot && (
          <div
            className={`absolute w-10 h-10 rounded-full ${style.color} opacity-75 animate-ping`}
            style={{ animationDuration: '2.5s' }}
          ></div>
        )}

        {/* Pin Body */}
        <div
          className={`relative w-10 h-10 flex items-center justify-center rounded-full shadow-md transition-all group-hover:scale-110 group-hover:shadow-lg ${style.color}`}
        >
          <div className="absolute inset-0 bg-black/10 rounded-full"></div>
          <Icon className="relative w-5 h-5 text-white" strokeWidth="2.5">
            <style.icon />
          </Icon>
        </div>

        {/* Fire icon for 'hot' places */}
        {isHot && (
            <div className="absolute -top-1 -right-1 bg-red-500 text-white w-5 h-5 rounded-full border-2 border-white dark:border-gray-800 flex items-center justify-center shadow-md" >
                <FireIcon className="w-3 h-3" />
            </div>
        )}
      </div>
    </div>
  );
};

export default React.memo(PlacePin);

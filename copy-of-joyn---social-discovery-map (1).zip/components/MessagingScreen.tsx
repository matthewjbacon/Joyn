
import React, { useState, useEffect } from 'react';
import { User, ChatMessage, Conversation } from '../types';
import { MOCK_CURRENT_USER_ID } from '../constants';
import { Icon } from './common/Icon';
import { generateConversationStarter } from '../services/geminiService';
import { ChevronLeftIcon, SendIcon, CheckIcon, CheckCheckIcon } from './common/AppIcons';

interface MessagingScreenProps {
  conversation: Conversation | null;
  currentUser: User;
  onClose: () => void;
  onSendMessage: (text: string) => void;
}

const TypingIndicator = () => (
    <div className="flex items-center gap-1">
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
    </div>
);

const MessageStatus: React.FC<{ status?: 'sent' | 'delivered' | 'read' }> = ({ status }) => {
    if (!status) return null;
    switch(status) {
        case 'sent': return <CheckIcon className="w-4 h-4 text-gray-400" />;
        case 'delivered': return <CheckCheckIcon className="w-4 h-4 text-gray-400" />;
        case 'read': return <CheckCheckIcon className="w-4 h-4 text-blue-500" />;
        default: return null;
    }
}

const MessagingScreen: React.FC<MessagingScreenProps> = ({ conversation, currentUser, onClose, onSendMessage }) => {
  const [newMessage, setNewMessage] = useState('');
  const [timeLeft, setTimeLeft] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isOtherUserTyping, setIsOtherUserTyping] = useState(false);
  const [tone, setTone] = useState<'playful' | 'curious' | 'bold' | 'default'>('default');

  useEffect(() => {
    if (!conversation) return;

    const calculateTimeLeft = () => {
      const diff = Math.max(0, conversation.expiresAt.getTime() - new Date().getTime());
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      setTimeLeft(`${hours}h ${minutes}m`);
    };

    calculateTimeLeft();
    const intervalId = setInterval(calculateTimeLeft, 30000); // update every 30s

    return () => clearInterval(intervalId);
  }, [conversation]);


  if (!conversation) return null;

  const handleSend = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage.trim());
      setNewMessage('');
      
      // Simulate typing indicator
      setIsOtherUserTyping(true);
      setTimeout(() => setIsOtherUserTyping(false), 2500); // Show for 2.5s
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  const handleSuggestMessage = async () => {
    if (!conversation) return;
    setIsGenerating(true);
    try {
        const suggestion = await generateConversationStarter(
            currentUser,
            conversation.participant,
            conversation.locationName,
            tone
        );
        setNewMessage(suggestion);
    } catch (error) {
        console.error("Failed to suggest message:", error);
        setNewMessage(`Hey ${conversation.participant.alias}! How's it going?`); // Fallback
    } finally {
        setIsGenerating(false);
    }
  };


  return (
    <div className="bg-gray-100 flex flex-col h-full">
      {/* Header */}
      <header className="bg-white p-4 flex items-center shadow-sm border-b border-gray-200">
        <button onClick={onClose} className="text-gray-500 hover:text-gray-900 mr-4">
          <ChevronLeftIcon />
        </button>
        <img src={conversation.participant.avatarUrl} alt={conversation.participant.alias} className="w-10 h-10 rounded-full mr-3" />
        <div>
          <h2 className="font-bold text-gray-900">{conversation.participant.alias}</h2>
          <p className="text-sm text-gray-500">
             {conversation.locationName ? `${conversation.locationName} · ` : ''}
             Expires in {timeLeft}
          </p>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {conversation.messages.map(msg => (
          <div key={msg.id} className={`flex items-end gap-2 ${msg.senderId === MOCK_CURRENT_USER_ID ? 'justify-end' : 'justify-start'}`}>
            {msg.senderId !== MOCK_CURRENT_USER_ID && <img src={conversation.participant.avatarUrl} className="w-6 h-6 rounded-full"/>}
            <div className={`flex items-end gap-2 ${msg.senderId === MOCK_CURRENT_USER_ID ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`max-w-xs md:max-w-md px-4 py-2.5 rounded-2xl ${msg.senderId === MOCK_CURRENT_USER_ID ? 'bg-[#7D4CDB] text-white rounded-br-lg' : 'bg-white text-gray-800 rounded-bl-lg shadow-sm'}`}>
                  <p>{msg.text}</p>
                </div>
                 {msg.senderId === MOCK_CURRENT_USER_ID && <MessageStatus status={msg.status} />}
            </div>
          </div>
        ))}
         {isOtherUserTyping && (
            <div className={`flex items-end gap-2 justify-start animate-fade-in`}>
                <img src={conversation.participant.avatarUrl} className="w-6 h-6 rounded-full"/>
                <div className={`max-w-xs md:max-w-md px-4 py-2.5 rounded-2xl bg-white text-gray-800 rounded-bl-lg shadow-sm`}>
                    <TypingIndicator />
                </div>
            </div>
        )}
      </div>

      {/* Input */}
      <div className="p-2 bg-white border-t border-gray-200 sm:p-4">
        <div className="flex justify-center mb-2 px-2 space-x-2">
            <button onClick={() => setTone('playful')} className={`px-3 py-1 text-xs font-semibold rounded-full border-2 ${tone === 'playful' ? 'border-pink-400 bg-pink-50 text-pink-600' : 'border-gray-200 bg-white'}`}>😜 Playful</button>
            <button onClick={() => setTone('curious')} className={`px-3 py-1 text-xs font-semibold rounded-full border-2 ${tone === 'curious' ? 'border-blue-400 bg-blue-50 text-blue-600' : 'border-gray-200 bg-white'}`}>🤔 Curious</button>
            <button onClick={() => setTone('bold')} className={`px-3 py-1 text-xs font-semibold rounded-full border-2 ${tone === 'bold' ? 'border-red-400 bg-red-50 text-red-600' : 'border-gray-200 bg-white'}`}>🔥 Bold</button>
            <button
                onClick={handleSuggestMessage}
                disabled={isGenerating}
                className="bg-purple-100 text-[#7D4CDB] font-semibold px-3 py-1 rounded-lg text-xs hover:bg-purple-200 transition-colors disabled:opacity-50 disabled:cursor-wait"
            >
                {isGenerating ? 'Thinking...' : '✨ Suggest'}
            </button>
        </div>
        <div className="bg-gray-100 rounded-full flex items-center p-2">
          <input
            type="text"
            placeholder="Type a message..."
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-transparent text-gray-800 px-3 focus:outline-none"
          />
          <button onClick={handleSend} className="bg-[#7D4CDB] rounded-full w-10 h-10 flex items-center justify-center text-white hover:bg-[#6c3ac0] transition-colors flex-shrink-0">
            <SendIcon />
          </button>
        </div>
      </div>
    </div>
  );
};

export default MessagingScreen;
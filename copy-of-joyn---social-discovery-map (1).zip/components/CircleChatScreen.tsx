import React, { useState, useEffect } from 'react';
import { DropInCircle, User, ChatMessage } from '../types';
import { MOCK_CURRENT_USER_ID } from '../constants';
import { Icon } from './common/Icon';
import { ChevronLeftIcon, CirclesIcon, SendIcon, CheckIcon, CheckCheckIcon } from './common/AppIcons';

interface CircleChatScreenProps {
  circle: DropInCircle | null;
  currentUser: User;
  users: User[];
  onClose: () => void;
  onSendMessage: (text: string) => void;
  onWaveRequest: (user: User) => void;
}

const MessageStatus: React.FC<{ status?: 'sent' | 'delivered' | 'read' }> = ({ status }) => {
    if (!status) return null;
    const isRead = status === 'read';
    const IconComponent = isRead ? CheckCheckIcon : CheckIcon;
    const color = isRead ? 'text-blue-500' : 'text-gray-400';
    return <IconComponent className={`w-4 h-4 ${color}`} />;
}

const CircleChatScreen: React.FC<CircleChatScreenProps> = ({ circle, currentUser, users, onClose, onSendMessage, onWaveRequest }) => {
  const [newMessage, setNewMessage] = useState('');
  const [timeLeft, setTimeLeft] = useState('');
  const [isAnyoneTyping, setIsAnyoneTyping] = useState(false);

  useEffect(() => {
    if (!circle) return;
    const expiryTime = new Date(circle.startTime.getTime() + 2 * 60 * 60 * 1000); // Assume 2hr duration

    const calculateTimeLeft = () => {
      const diff = Math.max(0, expiryTime.getTime() - new Date().getTime());
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      setTimeLeft(`${hours}h ${minutes}m`);
    };

    calculateTimeLeft();
    const intervalId = setInterval(calculateTimeLeft, 30000); // update every 30s
    return () => clearInterval(intervalId);
  }, [circle]);

  if (!circle) return null;

  const handleSend = () => {
    if (newMessage.trim()) {
      onSendMessage(newMessage.trim());
      setNewMessage('');
      
      // Simulate typing indicator
      setIsAnyoneTyping(true);
      setTimeout(() => setIsAnyoneTyping(false), 3000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleSend();
  };
  
  const onlineParticipants = users.filter(u => circle.userIds.includes(u.id) && u.isOnline);

  return (
    <div className="bg-gray-100 flex flex-col h-full">
      {/* Header */}
      <header className="bg-white p-4 pb-3 shadow-sm border-b border-gray-200">
        <div className="flex items-center">
            <button onClick={onClose} className="text-gray-500 hover:text-gray-900 mr-4">
              <ChevronLeftIcon />
            </button>
            <div className="text-white bg-[#7D4CDB] rounded-lg p-1.5 w-9 h-9 mr-3 flex items-center justify-center">
             <CirclesIcon className="w-7 h-7"/>
            </div>
            <div>
              <h2 className="font-bold text-gray-900">{circle.name}</h2>
              <p className="text-sm text-gray-500">Expires in {timeLeft}</p>
            </div>
        </div>
        {/* Online Participants */}
        <div className="flex items-center gap-2 mt-2 pl-14">
            <p className="text-xs text-gray-500 font-semibold">Online:</p>
            <div className="flex -space-x-2">
                {onlineParticipants.map(p => <img key={p.id} src={p.avatarUrl} alt={p.alias} className="w-5 h-5 rounded-full border border-white" />)}
            </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 relative">
        <div className="space-y-4">
            {circle.messages.map(msg => {
              const sender = users.find(u => u.id === msg.senderId);
              const isCurrentUser = msg.senderId === MOCK_CURRENT_USER_ID;
              return (
              <div key={msg.id} className={`flex items-start gap-2 ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                {!isCurrentUser && sender && <img src={sender.avatarUrl} className="w-6 h-6 rounded-full"/>}
                <div className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                  {!isCurrentUser && sender && <p className="text-xs text-gray-500 mb-0.5 ml-3">{sender.alias}</p>}
                  <div className="flex items-end gap-2">
                      <div className={`group relative max-w-xs md:max-w-md px-4 py-2.5 rounded-2xl ${isCurrentUser ? 'bg-[#7D4CDB] text-white rounded-br-lg' : 'bg-white text-gray-800 rounded-bl-lg shadow-sm'}`}>
                        <p>{msg.text}</p>
                        {/* Wave button placeholder */}
                         {!isCurrentUser && sender && (
                            <div className="absolute top-0 right-0 -translate-y-full flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity p-1">
                                <button onClick={() => onWaveRequest(sender)} className="p-1 rounded-full bg-white shadow-md hover:bg-gray-200 text-gray-500 hover:text-[#FF5C57]" title={`Send a private Wave to ${sender.alias}`}>
                                    <span role="img" aria-label="wave">👋</span>
                                </button>
                            </div>
                        )}
                      </div>
                      {isCurrentUser && <MessageStatus status={msg.status} />}
                  </div>
                </div>
              </div>
            )})}
        </div>
         {isAnyoneTyping && (
            <div className="sticky bottom-0 left-0 p-1 animate-fade-in">
                <p className="text-xs text-gray-500 italic text-center bg-gray-200/80 dark:bg-gray-700/80 backdrop-blur-sm rounded-full py-1 px-3 inline-block">A Joyner is typing...</p>
            </div>
        )}
      </div>

      {/* Input */}
      <div className="p-2 bg-white border-t border-gray-200 sm:p-4">
        <div className="bg-gray-100 rounded-full flex items-center p-2">
          <input
            type="text"
            placeholder="Type a message..."
            value={newMessage}
            onChange={e => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-transparent text-gray-800 px-3 focus:outline-none"
          />
          <button onClick={handleSend} className="bg-[#7D4CDB] rounded-full w-10 h-10 flex items-center justify-center text-white hover:bg-[#6c3ac0] transition-colors flex-shrink-0">
            <SendIcon/>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CircleChatScreen;
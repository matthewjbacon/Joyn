
import React, { useState, useEffect } from 'react';
import { User, Role, VisibilityFilter, View, Badge } from '../types';
import { PERSONAS, MOCK_BADGES } from '../constants';
import { Icon } from './common/Icon';
import { TrailIcon, InviteIcon, BlockIcon, ReportIcon, VerifiedIcon, InstantMeetIcon, WalletIcon, EarningsIcon, SunIcon, MoonIcon, GhostIcon, LanguageIcon, ShieldIcon } from './common/AppIcons';

interface ProfileScreenProps {
  user: User;
  onSave: (updatedUser: User) => void;
  onNavigate: (view: View) => void;
  onInviteFriends: () => void;
  newlyAwardedBadge: Badge | null;
  onAcknowledgeNewBadge: () => void;
  theme: 'light' | 'dark';
}

const ProfileScreen: React.FC<ProfileScreenProps> = ({ user, onSave, onNavigate, onInviteFriends, newlyAwardedBadge, onAcknowledgeNewBadge, theme }) => {
  const [alias, setAlias] = useState(user.alias);
  const [bio, setBio] = useState(user.bio || '');
  const [personaId, setPersonaId] = useState(user.personaId);
  const [isGhostMode, setIsGhostMode] = useState(user.isGhostMode);
  const [isInstantMeet, setIsInstantMeet] = useState(user.isInstantMeet);
  const [limitLocationAccuracy, setLimitLocationAccuracy] = useState(user.limitLocationAccuracy);
  const [visibilityRadius, setVisibilityRadius] = useState(user.visibilityRadius);
  const [visibilityFilter, setVisibilityFilter] = useState(user.visibilityFilter);
  const [language, setLanguage] = useState(user.language);

  useEffect(() => {
    if (newlyAwardedBadge) {
      const timer = setTimeout(() => {
        onAcknowledgeNewBadge();
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [newlyAwardedBadge, onAcknowledgeNewBadge]);

  const handleSave = () => {
    onSave({ ...user, alias, bio, personaId, isGhostMode, limitLocationAccuracy, visibilityRadius, visibilityFilter, isInstantMeet, language });
  };

  const earnedBadges = user.badges.map(id => MOCK_BADGES.find(b => b.id === id)).filter((b): b is Badge => b !== undefined);

  return (
    <div className="flex flex-col h-full">
      <header className="p-4 pt-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 px-2">Profile & Settings</h1>
      </header>

      <div className="flex-grow overflow-y-auto space-y-6 text-gray-900 dark:text-gray-200 p-6 pb-24">
        {newlyAwardedBadge && (
          <div className="bg-purple-100 dark:bg-purple-900/50 border-l-4 border-purple-500 text-purple-700 dark:text-purple-300 p-4 rounded-r-lg shadow-md animate-fade-in" role="alert">
            <p className="font-bold">Badge Earned: {newlyAwardedBadge.name} {newlyAwardedBadge.emoji}</p>
            <p className="text-sm">{newlyAwardedBadge.description}</p>
          </div>
        )}
        
        {/* Profile Card */}
        <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm text-center space-y-4">
          <div className="relative inline-block">
            <img src={user.avatarUrl} alt={alias} className="w-24 h-24 rounded-full border-4 border-purple-200 dark:border-purple-800 mx-auto"/>
            {user.isVerified && (
              <div className="absolute -bottom-1 -right-1 bg-teal-400 w-8 h-8 rounded-full border-4 border-white dark:border-gray-900 flex items-center justify-center shadow-md" title="Verified Joyner">
                <VerifiedIcon className="w-5 h-5 text-white" />
              </div>
            )}
          </div>
          <input id="alias" type="text" value={alias} onChange={e => setAlias(e.target.value)}
            className="w-full bg-gray-100 dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-lg p-3 text-center text-xl font-bold focus:ring-2 focus:ring-[#7D4CDB] focus:border-[#7D4CDB] outline-none transition text-gray-900 dark:text-gray-100"
          />
           <textarea
            id="bio"
            value={bio}
            onChange={e => setBio(e.target.value)}
            placeholder="Tell everyone a little about yourself..."
            rows={3}
            className="w-full bg-gray-100 dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 rounded-lg p-3 text-center text-base focus:ring-2 focus:ring-[#7D4CDB] focus:border-[#7D4CDB] outline-none transition resize-none text-gray-800 dark:text-gray-200"
          />
        </div>
        
        {/* JoynPay Hub */}
        <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm">
          <h2 className="text-lg font-semibold text-teal-600 dark:text-teal-400">JoynPay Hub</h2>
          <div className="space-y-2 mt-3">
              {user.isJoynPayActive && (
                 <button onClick={() => onNavigate('host-dashboard')} className="w-full text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors font-medium flex justify-between items-center">
                  <div className="flex items-center gap-3">
                      <TrailIcon className="w-5 h-5 text-purple-500"/>
                      <span>Host Dashboard</span>
                  </div>
                  <Icon size={16}><path d="m9 18 6-6-6-6" /></Icon>
              </button>
              )}
              <button onClick={() => onNavigate('wallet')} className="w-full text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors font-medium flex justify-between items-center">
                  <div className="flex items-center gap-3">
                      <WalletIcon className="w-5 h-5 text-purple-500"/>
                      <span>JoynCoin Wallet</span>
                  </div>
                  <Icon size={16}><path d="m9 18 6-6-6-6" /></Icon>
              </button>
              <button onClick={() => onNavigate('earnings')} className="w-full text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors font-medium flex justify-between items-center">
                  <div className="flex items-center gap-3">
                      <EarningsIcon className="w-5 h-5 text-teal-500"/>
                      <span>Earnings Dashboard</span>
                  </div>
                  <Icon size={16}><path d="m9 18 6-6-6-6" /></Icon>
              </button>
              {!user.isJoynPayActive && (
                  <button onClick={() => onNavigate('joynpay-setup')} className="w-full text-left p-3 rounded-lg bg-teal-50 dark:bg-teal-900/50 hover:bg-teal-100 dark:hover:bg-teal-900 transition-colors font-medium flex justify-between items-center">
                      <div className="flex items-center gap-3 text-teal-600 dark:text-teal-300">
                          <VerifiedIcon className="w-5 h-5" />
                          <span>Activate JoynPay & Start Earning</span>
                      </div>
                      <Icon size={16} className="text-teal-600 dark:text-teal-300"><path d="m9 18 6-6-6-6" /></Icon>
                  </button>
              )}
          </div>
        </div>

        {/* Badges */}
        {earnedBadges.length > 0 && (
          <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm">
            <h2 className="text-lg font-semibold text-gray-500 dark:text-gray-400 mb-3">My Badges</h2>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4 text-center">
              {earnedBadges.map(badge => (
                  <div key={badge.id} className="flex flex-col items-center">
                      <span className="text-4xl">{badge.emoji}</span>
                      <p className="text-xs text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">{badge.name}</p>
                  </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Settings */}
        <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm space-y-4">
          <h2 className="text-lg font-semibold text-gray-500 dark:text-gray-400">Settings</h2>
          
          <div className="flex justify-between items-center">
            <div className='flex items-center gap-3'>
              <GhostIcon className="w-6 h-6 text-gray-400"/>
              <div>
                <label htmlFor="ghostMode" className="font-medium">Ghost Mode</label>
                <p className="text-sm text-gray-500 dark:text-gray-400">Go invisible on the map.</p>
              </div>
            </div>
            <button onClick={() => setIsGhostMode(!isGhostMode)} className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${isGhostMode ? 'bg-purple-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
              <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isGhostMode ? 'translate-x-6' : 'translate-x-1'}`}/>
            </button>
          </div>

          <div className="flex justify-between items-center">
            <div className='flex items-center gap-3'>
              <InstantMeetIcon className="w-6 h-6 text-gray-400"/>
              <div>
                <label htmlFor="instantMeet" className="font-medium">Instant Meet</label>
                <p className="text-sm text-gray-500 dark:text-gray-400">Ready to connect now.</p>
              </div>
            </div>
            <button onClick={() => setIsInstantMeet(!isInstantMeet)} className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${isInstantMeet ? 'bg-yellow-400' : 'bg-gray-300 dark:bg-gray-600'}`}>
              <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${isInstantMeet ? 'translate-x-6' : 'translate-x-1'}`}/>
            </button>
          </div>

          <div className="flex justify-between items-center">
            <div className='flex items-center gap-3'>
              <ShieldIcon className="w-6 h-6 text-gray-400"/>
              <div>
                <label htmlFor="limitLocationAccuracy" className="font-medium">Limit Location Accuracy</label>
                <p className="text-sm text-gray-500 dark:text-gray-400">Show an approximate location.</p>
              </div>
            </div>
            <button onClick={() => setLimitLocationAccuracy(!limitLocationAccuracy)} className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${limitLocationAccuracy ? 'bg-teal-500' : 'bg-gray-300 dark:bg-gray-600'}`}>
              <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${limitLocationAccuracy ? 'translate-x-6' : 'translate-x-1'}`}/>
            </button>
          </div>

          <div className="flex justify-between items-center">
            <div className='flex items-center gap-3'>
              <LanguageIcon className="w-6 h-6 text-gray-400"/>
              <div>
                <label htmlFor="language" className="font-medium">Language</label>
                <p className="text-sm text-gray-500 dark:text-gray-400">App language preference.</p>
              </div>
            </div>
            <div className="flex items-center rounded-lg border-2 border-gray-200 dark:border-gray-600">
              <button onClick={() => setLanguage('en')} className={`px-3 py-1.5 rounded-l-md transition-colors text-sm font-semibold ${language === 'en' ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-200' : 'bg-white dark:bg-gray-800'}`}>EN</button>
              <button onClick={() => setLanguage('es')} className={`px-3 py-1.5 rounded-r-md transition-colors text-sm font-semibold ${language === 'es' ? 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-200' : 'bg-white dark:bg-gray-800'}`}>ES</button>
            </div>
          </div>
          
          {/* Visibility Radius Control */}
          <div>
            <label htmlFor="visibilityRadius" className="font-medium text-gray-800 dark:text-gray-200">Visibility Radius</label>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">Set how far you are visible on the map.</p>
            <input 
              id="visibilityRadius"
              type="range" 
              min="0.5" 
              max="5" 
              step="0.5" 
              value={visibilityRadius || 1}
              onChange={e => setVisibilityRadius(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[#7D4CDB]" />
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 text-center font-medium">
              {(visibilityRadius || 1).toFixed(1)} miles
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="bg-white dark:bg-gray-900 p-2 rounded-2xl shadow-sm">
            <button onClick={() => onNavigate('connection-log')} className="w-full text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors font-medium flex justify-between items-center">
              <div className="flex items-center gap-3">
                  <TrailIcon className="w-5 h-5 text-gray-500"/>
                  <span>My Joyn Trail</span>
              </div>
              <Icon size={16}><path d="m9 18 6-6-6-6" /></Icon>
            </button>
            <button onClick={onInviteFriends} className="w-full text-left p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors font-medium flex justify-between items-center">
              <div className="flex items-center gap-3">
                  <InviteIcon className="w-5 h-5 text-gray-500"/>
                  <span>Invite Friends</span>
              </div>
              <Icon size={16}><path d="m9 18 6-6-6-6" /></Icon>
            </button>
        </div>

        {/* Save Button */}
        <div className="pt-4 text-center">
            <button
                onClick={handleSave}
                className="bg-teal-500 text-white font-bold py-3 px-8 rounded-full hover:bg-teal-600 transition-colors transform active:scale-95"
            >
                Save Changes
            </button>
        </div>

      </div>
    </div>
  );
};

export default ProfileScreen;

import React from 'react';
import { JoynCoinIcon } from '../common/AppIcons';

interface PriceDisplayProps {
  price: number;
  currency: 'USD' | 'joyncoin';
  className?: string;
}

const PriceDisplay: React.FC<PriceDisplayProps> = ({ price, currency, className }) => {
  if (currency === 'joyncoin') {
    return (
      <span className={`flex items-center gap-1.5 ${className}`}>
        {price}
        <JoynCoinIcon className="w-5 h-5" />
      </span>
    );
  }
  return <span className={className}>${price.toFixed(2)}</span>;
};

export default PriceDisplay;

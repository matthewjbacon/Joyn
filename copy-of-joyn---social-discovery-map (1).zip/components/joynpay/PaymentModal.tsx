import React, { useState, useEffect } from 'react';
import { User, JoynPayDetails, DropInCircle } from '../../types';
import Modal from '../common/Modal';
import { CloseIcon, JoynCoinIcon, SecurePaymentIcon, VerifiedIcon, PlusIcon, MinusIcon } from '../common/AppIcons';
import PriceDisplay from './PriceDisplay';

interface PaymentModalProps {
  item: User | DropInCircle | null;
  users: User[];
  currentUser: User | null;
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (item: User | DropInCircle, details: JoynPayDetails, tipAmount: number, quantity: number) => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ item, users, currentUser, isOpen, onClose, onPaymentSuccess }) => {
  const [tipAmount, setTipAmount] = useState(0);
  const [customTip, setCustomTip] = useState('');
  const [promoCode, setPromoCode] = useState('');
  const [quantity, setQuantity] = useState(1);
  
  // Reset state when modal opens for a new item
  useEffect(() => {
    if (isOpen) {
      setTipAmount(0);
      setCustomTip('');
      setPromoCode('');
      setQuantity(1);
    }
  }, [isOpen, item]);

  if (!item || !currentUser) return null;
  
  const isUserItem = 'alias' in item;
  const joynPay = isUserItem ? item.pin?.joynPay : item.joynPay;
  
  if (!joynPay) return null;

  const title = isUserItem ? item.pin?.title || "Personal Joyn" : item.name;
  const hostId = isUserItem ? item.id : item.hostId;
  const host = users.find(u => u.id === hostId);

  if (!host) return null;

  const handleTipSelect = (amount: number) => {
    setTipAmount(amount);
    setCustomTip('');
  };

  const handleCustomTipChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    setCustomTip(value);
    setTipAmount(Number(value));
  };
  
  const ticketTotal = joynPay.price * quantity;
  const platformFee = joynPay.currency === 'USD' ? (ticketTotal * 0.1) : 0;
  const total = ticketTotal + platformFee + tipAmount;

  const canAffordWithCoins = joynPay.currency === 'joyncoin' && currentUser.joynCoins >= Number(total);

  const handlePay = () => {
    const paymentDetails: JoynPayDetails = {
        ...joynPay,
        price: ticketTotal, // Send the total ticket price based on quantity
    };
    onPaymentSuccess(item, paymentDetails, tipAmount, quantity);
  };

  const tipOptions = joynPay.currency === 'USD' ? [2, 5, 10] : [20, 50, 100];

  return (
    <Modal isOpen={isOpen} onClose={onClose} variant="default" animationClass="animate-scale-in-pop">
      <div className="flex flex-col text-gray-800 dark:text-gray-200">
        <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold">Confirm your spot</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"><CloseIcon/></button>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-700/50 rounded-2xl p-4 border border-gray-200 dark:border-gray-700">
            <p className="font-bold text-lg">{title}</p>
            <div className="flex items-center gap-2 mt-2">
                <img src={host.avatarUrl} alt={host.alias} className="w-8 h-8 rounded-full" />
                <p className="text-sm text-gray-600 dark:text-gray-300">Hosted by <span className="font-semibold">{host.alias}</span></p>
                {host.isVerified && <VerifiedIcon className="w-5 h-5 text-teal-500" />}
            </div>
             {/* Quantity Selector for Circles */}
            {!isUserItem && (
                 <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                    <span className="font-semibold">Tickets</span>
                    <div className="flex items-center gap-3">
                        <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center font-bold text-lg">-</button>
                        <span className="w-8 text-center font-bold text-lg">{quantity}</span>
                        <button onClick={() => setQuantity(q => q + 1)} className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center font-bold text-lg">+</button>
                    </div>
                </div>
            )}
        </div>

        <div className="mt-6 space-y-2">
          <h3 className="font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-sm">Tip the host <span className="text-xs normal-case text-gray-400 dark:text-gray-500">(optional)</span></h3>
          <div className="grid grid-cols-4 gap-2">
            {tipOptions.map(amount => (
              <button 
                key={amount}
                onClick={() => handleTipSelect(amount)}
                className={`py-2 rounded-lg font-bold transition-colors border-2 flex items-center justify-center gap-1 ${tipAmount === amount && customTip === '' ? 'bg-teal-100 text-teal-700 border-teal-400' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-400'}`}
              >
                {joynPay.currency === 'USD' ? `$${amount.toFixed(2)}` : <>{amount}<JoynCoinIcon className="w-5 h-5 inline-block"/></>}
              </button>
            ))}
             <input
              type="text"
              value={customTip}
              onChange={handleCustomTipChange}
              placeholder="Custom"
              className={`py-2 rounded-lg font-bold transition-colors border-2 text-center w-full ${customTip !== '' ? 'bg-teal-100 text-teal-700 border-teal-400' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-400'} focus:ring-2 focus:ring-teal-300 focus:border-teal-300 outline-none`}
            />
          </div>
        </div>
        
         <div className="mt-4">
           <input
              type="text"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              placeholder="Promo Code (optional)"
              className="w-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-600 rounded-lg p-3 text-base focus:ring-2 focus:ring-purple-400 focus:border-purple-400 outline-none transition"
            />
        </div>

        <div className="mt-6 space-y-2 text-sm">
            <h3 className="font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Cost Breakdown</h3>
            <div className="flex justify-between items-center">
                <p className="text-gray-600 dark:text-gray-300">Ticket Price {quantity > 1 ? `(${quantity} x ${joynPay.price})` : ''}</p>
                <PriceDisplay price={ticketTotal} currency={joynPay.currency} className="font-semibold" />
            </div>
             {tipAmount > 0 && (
                 <div className="flex justify-between items-center text-teal-600 dark:text-teal-400">
                    <p>Tip</p>
                    <PriceDisplay price={tipAmount} currency={joynPay.currency} className="font-semibold" />
                </div>
            )}
            <div className="flex justify-between items-center">
                <p className="text-gray-600 dark:text-gray-300">Joyn Fee</p>
                <PriceDisplay price={platformFee} currency={joynPay.currency} className="font-semibold" />
            </div>
            <div className="border-t my-2 border-gray-200 dark:border-gray-700"></div>
            <div className="flex justify-between items-center font-bold">
                <p className="text-lg">Total</p>
                <PriceDisplay price={total} currency={joynPay.currency} className="text-xl" />
            </div>
        </div>

        <div className="mt-8 space-y-3">
             {joynPay.currency === 'joyncoin' ? (
                <button
                    onClick={handlePay}
                    disabled={!canAffordWithCoins}
                    className="w-full bg-purple-500 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:bg-gray-300 dark:disabled:bg-gray-600 disabled:cursor-not-allowed"
                >
                    {canAffordWithCoins ? `Lock your vibe in with ${total} 🪙` : 'Not Enough Coins'}
                </button>
             ) : (
                <>
                    <button onClick={handlePay} className="w-full bg-black text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2">
                         Apple Pay
                    </button>
                     <button onClick={handlePay} className="w-full bg-[#FF5C57] text-white font-bold py-4 rounded-xl">
                        Join Now
                    </button>
                </>
             )}
        </div>
        
        <div className="flex items-center justify-center gap-2 mt-4 text-xs text-gray-400 dark:text-gray-500">
            <SecurePaymentIcon className="w-4 h-4" />
            <span>Secure payment powered by Stripe. Your spot is confirmed once payment is complete.</span>
        </div>
      </div>
    </Modal>
  );
};

export default PaymentModal;
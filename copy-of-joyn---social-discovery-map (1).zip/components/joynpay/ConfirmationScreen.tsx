import React from 'react';
import { User, DropInCircle } from '../../types';
import Confetti from '../Confetti';
import { Icon } from '../common/Icon';
import { MessageIcon } from '../common/AppIcons';
import PriceDisplay from './PriceDisplay';

interface ConfirmationScreenProps {
  item: User | DropInCircle;
  tipAmount: number;
  quantity: number;
  users: User[];
  onClose: () => void;
  onMessageHost: (item: User | DropInCircle) => void;
}

const ConfirmationScreen: React.FC<ConfirmationScreenProps> = ({ item, tipAmount, quantity, users, onClose, onMessageHost }) => {
  const isUserItem = 'alias' in item;
  const title = isUserItem ? item.pin?.title || "Personal Joyn" : item.name;
  const hostId = isUserItem ? item.id : item.hostId;
  const host = users.find(u => u.id === hostId);
  const joynPayDetails = isUserItem ? item.pin?.joynPay : item.joynPay;
  const currency = joynPayDetails?.currency || 'USD';
  
  const confirmationMessage = isUserItem
    ? <>Your spot for <span className="font-semibold">"{title}"</span> is confirmed.</>
    : <>You purchased <span className="font-semibold">{quantity > 1 ? `${quantity} tickets` : 'a ticket'}</span> for <span className="font-semibold">"{title}"</span>.</>;


  return (
    <div className="bg-gray-50 dark:bg-gray-950 flex flex-col justify-between p-6 h-full">
      <Confetti />
      <div></div>
      <div className="text-center space-y-4 animate-bounce-in">
        <div className="inline-block bg-teal-100 dark:bg-teal-900/50 text-teal-500 p-5 rounded-full">
            <Icon size={48}><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /></Icon>
        </div>
        <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100">You're In!</h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          {confirmationMessage}
        </p>
        {tipAmount > 0 && host && (
            <p className="text-md text-teal-600 dark:text-teal-400 font-semibold flex items-center justify-center gap-1.5">
                You tipped {host.alias} <PriceDisplay price={tipAmount} currency={currency} />. Thanks for the good vibe! 💜
            </p>
        )}
      </div>

      <div className="space-y-3">
        <button 
            onClick={() => onMessageHost(item)}
            className="w-full bg-[#7D4CDB] text-white font-bold py-4 rounded-xl hover:bg-[#6c3ac0] transition-colors flex items-center justify-center gap-2">
            <MessageIcon /> Message the Host
        </button>
         <button className="w-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 font-bold py-3.5 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            Add to Calendar
        </button>
        <button onClick={onClose} className="w-full text-gray-500 font-semibold py-2 hover:text-gray-800 dark:hover:text-gray-200 transition-colors">
            Back to Discovery
        </button>
      </div>
    </div>
  );
};

export default ConfirmationScreen;
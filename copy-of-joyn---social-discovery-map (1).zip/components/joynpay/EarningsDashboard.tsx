import React from 'react';
import { Transaction } from '../../types';
import { ChevronLeftIcon, EarningsIcon, JoynCoinIcon } from '../common/AppIcons';

interface EarningsDashboardProps {
  transactions: Transaction[];
  onClose: () => void;
}

const EarningsDashboard: React.FC<EarningsDashboardProps> = ({ transactions, onClose }) => {
  const earnings = transactions
    .filter(t => t.type === 'earn' || t.type === 'tip')
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
  const totalUsd = transactions
    .filter(t => t.currency === 'USD')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const totalJoynCoin = transactions
    .filter(t => t.currency === 'joyncoin' && t.amount > 0)
    .reduce((sum, t) => sum + t.amount, 0);

  const getIconForType = (type: Transaction['type']) => {
    switch (type) {
      case 'earn': return <EarningsIcon className="w-5 h-5 text-green-500" />;
      case 'tip': return <JoynCoinIcon className="w-5 h-5 text-yellow-500" />;
      default: return <EarningsIcon className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-950 flex flex-col h-full">
      <header className="p-4 flex items-center border-b border-gray-200 dark:border-gray-800">
        <button onClick={onClose} className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100 mr-4">
          <ChevronLeftIcon />
        </button>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">Earnings Dashboard</h1>
      </header>
      
      <div className="flex-grow overflow-y-auto p-6 space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm text-center">
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Earnings (USD)</p>
            <p className="text-2xl font-bold text-green-600">${totalUsd.toFixed(2)}</p>
          </div>
          <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm text-center">
            <p className="text-sm text-gray-500 dark:text-gray-400">Total Earnings (JoynCoins)</p>
            <p className="text-2xl font-bold text-purple-600 flex items-center justify-center gap-1">{totalJoynCoin} <JoynCoinIcon className="w-6 h-6" /></p>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm">
            <p className="text-sm text-gray-500 dark:text-gray-400">Next Payout</p>
            <p className="text-xl font-bold text-gray-800 dark:text-gray-200">$55.00 on Oct 25, 2024</p>
             <button className="text-sm text-teal-600 font-semibold mt-2">Manage Payout Method</button>
        </div>
        
        {/* Transaction History */}
        <div>
          <h2 className="text-lg font-bold text-gray-800 dark:text-gray-200 mb-2">Earnings History</h2>
          <div className="space-y-3">
            {earnings.length > 0 ? earnings.map(t => (
              <div key={t.id} className="bg-white dark:bg-gray-900 p-3 rounded-xl flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                    {getIconForType(t.type)}
                </div>
                <div className="flex-grow">
                  <p className="font-semibold text-gray-800 dark:text-gray-200">{t.description}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{t.timestamp.toLocaleDateString()}</p>
                </div>
                <div className={`font-bold flex items-center gap-1 ${t.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {t.currency === 'USD' ? `$${t.amount.toFixed(2)}` : `${t.amount}`}
                  {t.currency === 'joyncoin' && <JoynCoinIcon className="w-5 h-5"/>}
                </div>
              </div>
            )) : (
              <p className="text-center text-gray-500 dark:text-gray-400 p-8 bg-white dark:bg-gray-900 rounded-xl">Host a paid Joyn to see your earnings here!</p>
            )}
          </div>
        </div>
      </div>
      
      <footer className="p-4 border-t border-gray-200 dark:border-gray-800">
        <button className="w-full bg-teal-500 text-white font-bold py-3 rounded-xl hover:bg-teal-600 transition-colors">
          Withdraw Funds
        </button>
      </footer>
    </div>
  );
};

export default EarningsDashboard;
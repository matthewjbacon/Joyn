import React from 'react';
import { ChevronLeftIcon, EarningsIcon, SecurePaymentIcon, StripeIcon } from '../common/AppIcons';

interface JoynPaySetupScreenProps {
  onClose: () => void;
  onSetupComplete: () => void;
}

const JoynPaySetupScreen: React.FC<JoynPaySetupScreenProps> = ({ onClose, onSetupComplete }) => {
  return (
    <div className="bg-gray-50 dark:bg-gray-950 flex flex-col h-full">
      <header className="p-4 flex items-center">
        <button onClick={onClose} className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100 mr-4">
          <ChevronLeftIcon />
        </button>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">Activate JoynPay</h1>
      </header>
      
      <div className="flex-grow flex flex-col justify-between p-6">
        <div className="space-y-6">
            <div className="text-center">
                <div className="inline-block bg-teal-100 dark:bg-teal-900/50 text-teal-600 dark:text-teal-300 p-4 rounded-full mb-4">
                    <EarningsIcon className="w-10 h-10" />
                </div>
                <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">Start Earning with Your Joyns</h2>
                <p className="text-gray-600 dark:text-gray-400 mt-2">Activate JoynPay to host paid events, accept tips, and get paid directly for your vibes.</p>
            </div>

            <ul className="space-y-4">
                <li className="flex items-start gap-3">
                    <SecurePaymentIcon className="w-6 h-6 text-teal-500 mt-1 flex-shrink-0" />
                    <div>
                        <h3 className="font-semibold text-gray-800 dark:text-gray-200">Secure & Reliable</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">We partner with Stripe, a global leader in online payments, to handle your earnings securely.</p>
                    </div>
                </li>
                 <li className="flex items-start gap-3">
                    <EarningsIcon className="w-6 h-6 text-teal-500 mt-1 flex-shrink-0" />
                    <div>
                        <h3 className="font-semibold text-gray-800 dark:text-gray-200">Flexible Monetization</h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Set ticket prices in USD or JoynCoins. The choice is yours.</p>
                    </div>
                </li>
            </ul>
        </div>
        
        <div className="space-y-4">
             <button
                onClick={onSetupComplete}
                className="w-full flex items-center justify-center gap-3 bg-[#6772E5] text-white font-bold py-4 rounded-xl hover:bg-[#5964d4] transition-colors"
             >
                <StripeIcon className="w-6 h-6" />
                Connect with Stripe
             </button>
             <p className="text-xs text-gray-400 text-center">You'll be redirected to Stripe to complete a secure setup. By continuing, you agree to Joyn's Creator Terms.</p>
        </div>
      </div>
    </div>
  );
};

export default JoynPaySetupScreen;
import React from 'react';
import { User, Transaction } from '../../types';
import { ChevronLeftIcon, EarningsIcon, JoynCoinIcon, JoynPinIcon } from '../common/AppIcons';

interface JoynCoinWalletProps {
  user: User;
  transactions: Transaction[];
  onClose: () => void;
}

const JoynCoinWallet: React.FC<JoynCoinWalletProps> = ({ user, transactions, onClose }) => {
  const coinTransactions = transactions
    .filter(t => t.currency === 'joyncoin')
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

  const getIconForType = (type: Transaction['type']) => {
    switch (type) {
      case 'earn': return <EarningsIcon className="w-5 h-5 text-green-500" />;
      case 'purchase': return <JoynPinIcon className="w-5 h-5 text-red-500" />;
      case 'tip': return <JoynCoinIcon className="w-5 h-5 text-yellow-500" />;
      default: return <JoynCoinIcon className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-950 flex flex-col h-full">
      <header className="p-4 flex items-center border-b border-gray-200 dark:border-gray-800">
        <button onClick={onClose} className="text-gray-500 hover:text-gray-900 dark:hover:text-gray-100 mr-4">
          <ChevronLeftIcon />
        </button>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">JoynCoin Wallet</h1>
      </header>
      
      <div className="flex-grow overflow-y-auto p-6 space-y-6">
        {/* Balance Card */}
        <div className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white p-6 rounded-2xl shadow-lg text-center">
            <p className="text-sm opacity-80 font-medium">Your Balance</p>
            <p className="text-5xl font-bold flex items-center justify-center gap-2 mt-2">
                {user.joynCoins} <JoynCoinIcon className="w-10 h-10" />
            </p>
        </div>
        
        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
            <button className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm text-center font-bold text-teal-600 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-gray-800">
                Redeem Coins
            </button>
            <button className="bg-white dark:bg-gray-900 p-4 rounded-2xl shadow-sm text-center font-bold text-purple-600 dark:text-purple-300 hover:bg-purple-50 dark:hover:bg-gray-800">
                Buy More
            </button>
        </div>
        
        {/* Transaction History */}
        <div>
          <h2 className="text-lg font-bold text-gray-800 dark:text-gray-200 mb-2">History</h2>
          <div className="space-y-3">
            {coinTransactions.length > 0 ? coinTransactions.map(t => (
              <div key={t.id} className="bg-white dark:bg-gray-900 p-3 rounded-xl flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                    {getIconForType(t.type)}
                </div>
                <div className="flex-grow">
                  <p className="font-semibold text-gray-800 dark:text-gray-200">{t.description}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{t.timestamp.toLocaleDateString()}</p>
                </div>
                <div className={`font-bold flex items-center gap-1 ${t.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {t.amount > 0 ? '+' : ''}{t.amount}
                  <JoynCoinIcon className="w-5 h-5"/>
                </div>
              </div>
            )) : (
              <p className="text-center text-gray-500 dark:text-gray-400 p-8 bg-white dark:bg-gray-900 rounded-xl">Your JoynCoin transactions will appear here.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JoynCoinWallet;
import React from 'react';
import { DropInCircle as DropInCircleType } from '../types';
import { Icon } from './common/Icon';

interface DropInCircleProps {
  circle: DropInCircleType;
  onClick: (circle: DropInCircleType) => void;
}

const DropInCircle: React.FC<DropInCircleProps> = ({ circle, onClick }) => {
  return (
    <div
      className="cursor-pointer group"
      onClick={() => onClick(circle)}
    >
      <div className="relative flex items-center justify-center">
        {/* Soft pulsing rings */}
        <div className="absolute w-16 h-16 rounded-full bg-[#7D4CDB]/20 animate-ping opacity-75" style={{animationDuration: '3s'}}></div>
        <div className="absolute w-12 h-12 rounded-full bg-[#7D4CDB]/20"></div>

        {/* Center icon */}
        <div className="relative w-10 h-10 bg-[#7D4CDB] rounded-full flex items-center justify-center shadow-lg text-white group-hover:scale-110 transition-transform">
            <Icon className="w-6 h-6">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
            </Icon>
        </div>
      </div>
    </div>
  );
};

export default DropInCircle;
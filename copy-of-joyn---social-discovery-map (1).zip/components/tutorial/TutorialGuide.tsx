
import React, { useState, useEffect, useRef } from 'react';
import { Icon } from '../common/Icon';

interface TutorialStep {
  elementId: string;
  title: string;
  text: string;
  position: 'top' | 'bottom' | 'left' | 'right';
}

const STEPS: TutorialStep[] = [
  {
    elementId: 'joyn-action-button',
    title: 'Spark a Joyn',
    text: "Ready to go? Tap here to share your vibe and light up the map.",
    position: 'top',
  },
  {
    elementId: 'nav-discovery',
    title: 'Find Your Scene',
    text: "Explore group events, check the local pulse, and find your next adventure.",
    position: 'top',
  },
  {
    elementId: 'user-pin-example',
    title: 'Catch a Vibe',
    text: "See someone interesting? Tap their pin to check their vibe or send a friendly wave.",
    position: 'bottom',
  },
];

const TutorialGuide: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [stepIndex, setStepIndex] = useState(0);
  const [highlightStyle, setHighlightStyle] = useState<React.CSSProperties>({});
  const [tooltipStyle, setTooltipStyle] = useState<React.CSSProperties>({});
  const [isVisible, setIsVisible] = useState(false);
  const tooltipRef = useRef<HTMLDivElement>(null);

  const currentStep = STEPS[stepIndex];

  useEffect(() => {
    // Delay visibility to allow the main UI to render and elements to be available
    const timer = setTimeout(() => setIsVisible(true), 500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!isVisible || !currentStep) return;

    let resizeObserver: ResizeObserver | null = null;

    const calculatePosition = () => {
      const element = document.getElementById(currentStep.elementId);
      if (element && tooltipRef.current) {
        const targetRect = element.getBoundingClientRect();
        // If element is not in viewport, don't show tooltip.
        if (targetRect.top < -targetRect.height || targetRect.bottom > window.innerHeight + targetRect.height) {
            setHighlightStyle({ display: 'none' });
            setTooltipStyle({ opacity: 0 });
            return false;
        }

        const padding = 8;
        
        setHighlightStyle({
          position: 'absolute',
          top: `${targetRect.top - padding}px`,
          left: `${targetRect.left - padding}px`,
          width: `${targetRect.width + padding * 2}px`,
          height: `${targetRect.height + padding * 2}px`,
          borderRadius: '1.25rem',
          boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.7)',
          transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
          pointerEvents: 'none',
        });
        
        const tooltipRect = tooltipRef.current.getBoundingClientRect();
        const margin = 15;
        let newTooltipStyle: React.CSSProperties = {
            position: 'absolute',
            opacity: 1,
            transition: 'opacity 0.2s ease-in-out, top 0.3s ease, left 0.3s ease',
        };

        let left = targetRect.left + (targetRect.width / 2) - (tooltipRect.width / 2);
        left = Math.max(16, Math.min(left, window.innerWidth - tooltipRect.width - 16));
        newTooltipStyle.left = `${left}px`;
        
        const spaceTop = targetRect.top - margin - tooltipRect.height;
        const spaceBottom = window.innerHeight - targetRect.bottom - margin - tooltipRect.height;

        if (currentStep.position === 'top' && spaceTop > 0) {
            newTooltipStyle.top = `${targetRect.top - tooltipRect.height - margin}px`;
        } else if (currentStep.position === 'bottom' && spaceBottom > 0) {
            newTooltipStyle.top = `${targetRect.bottom + margin}px`;
        } else if (spaceBottom > spaceTop) {
            newTooltipStyle.top = `${targetRect.bottom + margin}px`;
        } else {
            newTooltipStyle.top = `${targetRect.top - tooltipRect.height - margin}px`;
        }
        setTooltipStyle(newTooltipStyle);
        return true;
      } else {
        setHighlightStyle({ display: 'none' });
        setTooltipStyle({ opacity: 0 }); // Hide with opacity to not affect layout on re-render
        return false;
      }
    };
    
    // Poll to find the element, as mobile rendering can be slower.
    let attempts = 0;
    const maxAttempts = 30; // Try for 3 seconds
    const intervalId = setInterval(() => {
      attempts++;
      if (calculatePosition() || attempts >= maxAttempts) {
        clearInterval(intervalId);
        const targetElement = document.getElementById(currentStep.elementId);
        if (targetElement) {
          try {
            resizeObserver = new ResizeObserver(calculatePosition);
            resizeObserver.observe(targetElement);
          } catch(e) {
            // ResizeObserver might not be available in all environments, fallback to window resize.
          }
        }
      }
    }, 100);

    window.addEventListener('resize', calculatePosition);
    window.addEventListener('scroll', calculatePosition, true);

    return () => {
        clearInterval(intervalId);
        window.removeEventListener('resize', calculatePosition);
        window.removeEventListener('scroll', calculatePosition, true);
        if (resizeObserver) {
          resizeObserver.disconnect();
        }
    };

  }, [stepIndex, currentStep, isVisible]);
  
  const handleNext = () => {
    if (stepIndex < STEPS.length - 1) {
      setStepIndex(stepIndex + 1);
    } else {
      onComplete();
    }
  };

  if (!isVisible) return null;

  return (
    <div className="absolute inset-0 z-[100] pointer-events-none">
      <div style={highlightStyle}></div>
      <div 
        ref={tooltipRef}
        className="w-64 p-4 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-lg shadow-2xl pointer-events-auto" 
        style={{...tooltipStyle, opacity: Object.keys(highlightStyle).length > 0 && highlightStyle.display !== 'none' ? 1 : 0}}
      >
        <h3 className="font-bold text-lg mb-1">{currentStep.title}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300">{currentStep.text}</p>
        <div className="flex justify-between items-center mt-4">
          <span className="text-xs text-gray-400 dark:text-gray-500 font-semibold">{stepIndex + 1} / {STEPS.length}</span>
          <div className="flex gap-2">
            <button onClick={onComplete} className="text-sm font-semibold text-gray-500 hover:text-gray-800 dark:hover:text-gray-200">Skip</button>
            <button onClick={handleNext} className="bg-purple-500 text-white font-bold py-1.5 px-4 rounded-full text-sm">
              {stepIndex === STEPS.length - 1 ? 'Finish' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Add a dummy element for the tutorial to find, since a real user pin is dynamic
export const TutorialUserPinPlaceholder = () => (
    <div id="user-pin-example" style={{ position: 'absolute', top: '50%', left: '50%', width: '60px', height: '60px', transform: 'translate(-50%, -100%)', pointerEvents: 'none' }}></div>
);


export default TutorialGuide;

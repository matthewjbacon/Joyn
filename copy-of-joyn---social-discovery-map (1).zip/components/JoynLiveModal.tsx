import React, { useState, useEffect, useRef } from 'react';
import { JoynLiveUpdate, User } from '../types';
import Modal from './common/Modal';
import { Icon } from './common/Icon';
import { ReportIcon, SendIcon } from './common/AppIcons';

interface JoynLiveModalProps {
  liveUpdate: JoynLiveUpdate | null;
  users: User[];
  currentUser: User;
  isOpen: boolean;
  onClose: () => void;
  onAddReply: (liveUpdateId: string, text: string) => void;
}

const timeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 5) return "Just now";
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m";
    return Math.floor(seconds) + "s";
};

const JoynLiveModal: React.FC<JoynLiveModalProps> = ({ liveUpdate, users, currentUser, isOpen, onClose, onAddReply }) => {
  const [replyText, setReplyText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [liveUpdate?.replies.length]);

  if (!liveUpdate) return null;

  const author = users.find(u => u.id === liveUpdate.authorId);
  if (!author) return null;

  const handleReplySubmit = () => {
    if (replyText.trim()) {
      onAddReply(liveUpdate.id, replyText);
      setReplyText('');
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="flex flex-col h-[75vh] max-h-[75vh]">
        {/* Header */}
        <div className="flex-shrink-0">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <img src={author.avatarUrl} alt={author.alias} className="w-12 h-12 rounded-full" />
              <div>
                <p className="font-bold text-lg text-gray-900 dark:text-gray-100">{author.alias}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{liveUpdate.locationName} · {timeAgo(liveUpdate.timestamp)}</p>
              </div>
            </div>
            <button className="text-gray-400 p-2 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50 hover:text-red-600 transition-colors">
              <ReportIcon className="w-5 h-5" />
            </button>
          </div>
          <p className="text-gray-700 dark:text-gray-300 text-base leading-relaxed mb-4">{liveUpdate.content}</p>
          <div className="border-t border-gray-200 dark:border-gray-700 -mx-6"></div>
        </div>

        {/* Replies Section */}
        <div ref={scrollRef} className="flex-grow overflow-y-auto pt-4 -mx-6 px-6 space-y-4">
          {liveUpdate.replies.map(reply => {
            const replyAuthor = users.find(u => u.id === reply.authorId);
            return (
              <div key={reply.id} className="flex items-start gap-3 animate-list-item">
                <img src={replyAuthor?.avatarUrl} alt={replyAuthor?.alias} className="w-8 h-8 rounded-full mt-1" />
                <div className="bg-gray-100 dark:bg-gray-700/80 p-3 rounded-2xl flex-grow">
                  <div className="flex justify-between items-center">
                    <p className="font-semibold text-sm text-gray-800 dark:text-gray-200">{replyAuthor?.alias}</p>
                    <p className="text-xs text-gray-400 dark:text-gray-500">{timeAgo(reply.timestamp)}</p>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 mt-1">{reply.text}</p>
                </div>
              </div>
            );
          })}
          {liveUpdate.replies.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">Be the first to reply!</p>
            </div>
          )}
        </div>

        {/* Input Footer */}
        <div className="flex-shrink-0 pt-4 -mx-6 px-4 pb-2 border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
          <div className="bg-gray-100 dark:bg-gray-700/80 rounded-full flex items-center p-2">
            <input
              type="text"
              placeholder={`Reply to ${author.alias}...`}
              value={replyText}
              onChange={e => setReplyText(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && handleReplySubmit()}
              className="flex-1 bg-transparent text-gray-800 dark:text-gray-200 px-3 focus:outline-none"
            />
            <button onClick={handleReplySubmit} className="bg-[#7D4CDB] rounded-full w-10 h-10 flex items-center justify-center text-white hover:bg-[#6c3ac0] transition-colors flex-shrink-0 disabled:bg-gray-400" disabled={!replyText.trim()}>
              <SendIcon />
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default JoynLiveModal;
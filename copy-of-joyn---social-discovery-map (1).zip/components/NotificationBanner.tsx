import React, { useEffect } from 'react';
import { Icon } from './common/Icon';

interface NotificationBannerProps {
  message: string;
  type: 'success' | 'info' | 'error';
  onDismiss: () => void;
}

const bannerStyles = {
    success: { bg: 'bg-[#3CD6BE]', icon: <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />, text: 'text-white' },
    info: { bg: 'bg-[#5AC8FA]', icon: <><circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" /></>, text: 'text-white' },
    error: { bg: 'bg-[#FF5C57]', icon: <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>, text: 'text-white' },
};

const NotificationBanner: React.FC<NotificationBannerProps> = ({ message, type, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, 4000);

    return () => clearTimeout(timer);
  }, [onDismiss]);
  
  const style = bannerStyles[type];

  return (
    <div className="absolute top-4 left-1/2 -translate-x-1/2 w-full max-w-sm z-50 px-4">
        <div className={`flex items-center gap-3 p-3 rounded-2xl shadow-lg animate-slide-down-bounce bg-white/70 backdrop-blur-md border border-gray-200/50`}>
             <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${style.bg}`}>
                <Icon className={`w-5 h-5 ${style.text}`} strokeWidth="2.5">{style.icon}</Icon>
            </div>
            <p className="font-semibold text-sm flex-grow text-gray-800">{message}</p>
            <button onClick={onDismiss} className="p-1 rounded-full text-gray-500 hover:bg-black/10 transition-colors">
                <Icon size={18}><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></Icon>
            </button>
        </div>
    </div>
  );
};

export default NotificationBanner;
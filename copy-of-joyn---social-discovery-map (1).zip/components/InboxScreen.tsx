import React, { useState } from 'react';
import { DropInCircle, Conversation, User } from '../types';
import { Icon } from './common/Icon';
import { BookmarkIcon, CirclesIcon, SearchIcon, MessageIcon, TrashIcon } from './common/AppIcons';

type Tab = 'circles' | 'waves' | 'saved';
type ChatType = 'circle' | 'wave';

interface InboxScreenProps {
  joinedCircles: DropInCircle[];
  savedCircles: DropInCircle[];
  conversations: Conversation[];
  currentUser: User;
  onNavigateToChat: (type: ChatType, id: string) => void;
  onDeleteConversation: (conversationId: string) => void;
}

export const InboxScreen: React.FC<InboxScreenProps> = ({ joinedCircles, savedCircles, conversations, currentUser, onNavigateToChat, onDeleteConversation }) => {
  const [activeTab, setActiveTab] = useState<Tab>('circles');
  
  const timeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return "Just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  const expiresIn = (date: Date): string => {
    const diff = Math.max(0, date.getTime() - new Date().getTime());
    if (diff === 0) return 'Expired';
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    if (hours > 0) return `Expires in ${hours}h ${minutes}m`;
    return `Expires in ${minutes}m`;
  };

  const renderCircleListItem = (circle: DropInCircle, index: number) => (
    <div 
        key={circle.id} 
        onClick={() => onNavigateToChat('circle', circle.id)} 
        className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer transition-colors animate-list-item"
        style={{ animationDelay: `${index * 30}ms` }}
    >
      <div className="w-14 h-14 rounded-full bg-[#7D4CDB] flex items-center justify-center text-white flex-shrink-0">
         <CirclesIcon className="w-7 h-7"/>
      </div>
      <div className="flex-grow overflow-hidden">
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-gray-800 dark:text-gray-200 truncate">{circle.name}</h3>
          <p className="text-xs text-gray-400 dark:text-gray-500 flex-shrink-0">{timeAgo(circle.messages[circle.messages.length - 1]?.timestamp || circle.startTime)}</p>
        </div>
        <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{circle.messages[circle.messages.length - 1]?.text || 'No new messages'}</p>
      </div>
    </div>
  );

  const renderWaveListItem = (convo: Conversation, index: number) => (
    <div 
        key={convo.id} 
        onClick={() => onNavigateToChat('wave', convo.id)} 
        className="group flex items-center gap-4 p-3 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 cursor-pointer transition-colors animate-list-item"
        style={{ animationDelay: `${index * 30}ms` }}
    >
        <div className="relative">
            <img src={convo.participant.avatarUrl} alt={convo.participant.alias} className="w-14 h-14 rounded-full"/>
            {convo.status === 'pending' && <div className="absolute -bottom-1 -right-1 bg-amber-400 w-5 h-5 rounded-full border-2 border-white dark:border-gray-800 flex items-center justify-center text-xs font-bold">?</div>}
        </div>
      <div className="flex-grow overflow-hidden">
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-gray-800 dark:text-gray-200 truncate">{convo.participant.alias}</h3>
          <p className="text-xs text-red-500 dark:text-red-400 flex-shrink-0 font-semibold">{expiresIn(convo.expiresAt)}</p>
        </div>
        <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500 dark:text-gray-400 truncate">{convo.status === 'pending' ? 'Wave sent. Waiting for response...' : convo.messages[convo.messages.length - 1].text}</p>
        </div>
      </div>
      <button 
        onClick={(e) => { e.stopPropagation(); onDeleteConversation(convo.id); }}
        className="p-2 rounded-full text-gray-400 hover:text-red-500 bg-gray-100 dark:bg-gray-800 hover:bg-red-100 dark:hover:bg-red-900/50 transition-all opacity-0 group-hover:opacity-100"
        aria-label={`Delete chat with ${convo.participant.alias}`}
      >
          <TrashIcon className="w-5 h-5"/>
      </button>
    </div>
  );

  return (
    <div className="h-full flex flex-col">
      <header className="p-4 flex justify-between items-center bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-gray-200/80 dark:border-gray-700/80">
        <div className="w-8"></div>
        <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">Inbox</h1>
        <button className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100">
            <SearchIcon className="w-6 h-6"/>
        </button>
      </header>
      
      {/* Tabs */}
      <div className="p-2 bg-white dark:bg-gray-900">
          <div className="grid grid-cols-3 gap-2 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
              <button onClick={() => setActiveTab('circles')} className={`py-2.5 text-sm font-bold rounded-lg transition-all duration-300 ${activeTab === 'circles' ? 'bg-white dark:bg-gray-700 shadow text-[#7D4CDB]' : 'text-gray-500 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700/50'}`}>Circles</button>
              <button onClick={() => setActiveTab('waves')} className={`py-2.5 text-sm font-bold rounded-lg transition-all duration-300 ${activeTab === 'waves' ? 'bg-white dark:bg-gray-700 shadow text-[#7D4CDB]' : 'text-gray-500 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700/50'}`}>Waves</button>
              <button onClick={() => setActiveTab('saved')} className={`py-2.5 text-sm font-bold rounded-lg transition-all duration-300 flex items-center justify-center gap-1.5 ${activeTab === 'saved' ? 'bg-white dark:bg-gray-700 shadow text-[#7D4CDB]' : 'text-gray-500 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700/50'}`}>
                <BookmarkIcon className="w-4 h-4" /> Saved
              </button>
          </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2 pb-20">
        {activeTab === 'circles' && (
          <div className="space-y-1">
            {joinedCircles.map(renderCircleListItem)}
            {joinedCircles.length === 0 && <p className="text-center text-gray-500 dark:text-gray-400 p-8">Join a Group Joyn to start chatting!</p>}
          </div>
        )}
        {activeTab === 'waves' && (
          <div className="space-y-1">
            {conversations.map(renderWaveListItem)}
             {conversations.length === 0 && <p className="text-center text-gray-500 dark:text-gray-400 p-8">Your 1-on-1 conversations will appear here.</p>}
          </div>
        )}
        {activeTab === 'saved' && (
          <div className="space-y-1">
            {savedCircles.map(renderCircleListItem)}
            {savedCircles.length === 0 && <p className="text-center text-gray-500 dark:text-gray-400 p-8">You haven't saved any activities yet.</p>}
          </div>
        )}
      </div>
    </div>
  );
};
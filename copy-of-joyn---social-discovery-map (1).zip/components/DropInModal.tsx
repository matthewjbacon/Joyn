
import React, { useMemo } from 'react';
import { User, Role, DropInCircle } from '../types';
import { ROLE_COLORS, PERSONAS, VIBE_TAGS, calculateDistance, estimateTravelTime, PRESENCE_OPTIONS } from '../constants';
import Modal from './common/Modal';
import { MessageIcon, VerifiedIcon, ReportIcon } from './common/AppIcons';
import PriceDisplay from './joynpay/PriceDisplay';

interface DropInModalProps {
  user: User | null;
  currentUser: User | null;
  circles: DropInCircle[];
  isOpen: boolean;
  onClose: () => void;
  onWaveRequest: (user: User) => void;
  onJoinPaidDropIn: (user: User) => void;
  isOffline: boolean;
}

const DropInModal: React.FC<DropInModalProps> = ({ user, currentUser, circles, isOpen, onClose, onWaveRequest, onJoinPaidDropIn, isOffline }) => {
  if (!user || !currentUser) return null;

  const roleStyle = ROLE_COLORS[user.role as Role];
  const persona = PERSONAS.find(p => p.id === user.personaId);
  const userVibeTags = user.pin?.vibeTagIds?.map(id => VIBE_TAGS.find(tag => tag.id === id)).filter(Boolean) ?? [];

  const presenceInfo = PRESENCE_OPTIONS.find(p => p.id === user.pin?.presence);
  
  const isPaid = user.pin?.joynPay?.isPaid ?? false;
  const joynPayDetails = user.pin?.joynPay;

  const distance = useMemo(() => {
    if (user.location && currentUser.location) {
      return calculateDistance(currentUser.location.lat, currentUser.location.lng, user.location.lat, user.location.lng);
    }
    return null;
  }, [currentUser.location, user.location]);

  const travelTime = useMemo(() => {
    if (distance !== null) {
      return estimateTravelTime(distance);
    }
    return null;
  }, [distance]);

  const timeDiff = (date: Date) => {
    const diff = Math.max(0, date.getTime() - new Date().getTime());
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };
  
  const mutualJoyns = useMemo(() => {
    return circles.filter(c => 
      c.userIds.includes(currentUser.id) && c.userIds.includes(user.id)
    );
  }, [circles, currentUser, user]);

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <div className="flex flex-col text-gray-800 dark:text-gray-200">
        {/* Header */}
        <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
                <img src={user.avatarUrl} alt={user.alias} className="w-20 h-20 rounded-full border-4 border-white dark:border-gray-800 shadow-lg -mt-12" />
                <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">{user.alias}</h2>
                      {user.isVerified && <span title="Verified Joyner"><VerifiedIcon className="w-6 h-6 text-teal-500" /></span>}
                    </div>
                    <span className={`px-3 py-1 text-xs font-semibold rounded-full mt-1 inline-block ${roleStyle.bg} ${roleStyle.text} dark:bg-opacity-20 dark:text-opacity-90`}>
                        {user.role}
                    </span>
                </div>
            </div>
             <button className="text-gray-400 p-2 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50 hover:text-red-600 transition-colors">
                <ReportIcon className="w-5 h-5" />
            </button>
        </div>
        
        {/* Joyn Title */}
        {user.pin?.title && (
             <div className="mt-4 text-center">
                <p className="text-lg font-semibold text-gray-700 dark:text-gray-300 leading-tight">"{user.pin.title}"</p>
            </div>
        )}

        {/* Presence Status */}
        {presenceInfo && (
            <div className="mt-4 bg-purple-50 dark:bg-purple-900/50 border border-purple-200 dark:border-purple-800 p-3 rounded-xl flex items-center gap-3">
                 <span className="text-3xl">{presenceInfo.emoji}</span>
                <div>
                    <h3 className="font-bold text-purple-800 dark:text-purple-300">{presenceInfo.title}</h3>
                    <p className="text-md text-purple-700 dark:text-purple-400">{presenceInfo.description}</p>
                </div>
            </div>
        )}

        {/* Mutual Connections */}
        {mutualJoyns.length > 0 && (
          <div className="mt-4 bg-blue-50 dark:bg-blue-900/50 border border-blue-200 dark:border-blue-800 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xl">🤝</span>
                <h3 className="font-bold text-blue-800 dark:text-blue-300">Mutual Joyns</h3>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-400">
                You've both been to: {mutualJoyns.map(c => `"${c.name}"`).join(', ')}
              </p>
          </div>
        )}

        {/* Persona */}
        {persona && (
            <div className="mt-4 bg-gray-100 dark:bg-gray-700/50 p-3 rounded-xl flex items-center gap-3">
                <persona.Icon className="w-8 h-8 text-[#7D4CDB] flex-shrink-0" />
                <div>
                    <h3 className="font-bold text-gray-800 dark:text-gray-200">{persona.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{persona.description}</p>
                </div>
            </div>
        )}

        {/* Vibe Tags */}
        {userVibeTags.length > 0 && (
            <div className="mt-4">
                <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2">Current Vibe</h3>
                <div className="flex flex-wrap gap-2">
                    {userVibeTags.map(tag => (
                        tag && <span key={tag.id} className={`px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1.5 ${tag.color.bg} ${tag.color.text} dark:bg-opacity-20 dark:text-opacity-90`}>
                            {tag.emoji}
                            {tag.name}
                        </span>
                    ))}
                </div>
            </div>
        )}

        {/* Info grid */}
        {user.pin && (
            <div className="grid grid-cols-3 gap-4 mt-6 text-center">
                <div className="bg-gray-100 dark:bg-gray-700/50 p-3 rounded-xl">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Distance</p>
                    <p className="font-bold text-lg text-gray-800 dark:text-gray-200">{distance !== null ? `${distance.toFixed(1)} mi` : 'N/A'}</p>
                </div>
                <div className="bg-gray-100 dark:bg-gray-700/50 p-3 rounded-xl">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Est. Travel</p>
                    <p className="font-bold text-lg text-gray-800 dark:text-gray-200">{travelTime || 'N/A'}</p>
                </div>
                <div className="bg-gray-100 dark:bg-gray-700/50 p-3 rounded-xl">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Visible For</p>
                    <p className="font-bold text-lg text-gray-800 dark:text-gray-200">{timeDiff(user.pin.expiresAt)}</p>
                </div>
            </div>
        )}

        {/* Interests */}
        <div className="mt-6 w-full">
          <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Interests</h3>
          <div className="flex flex-wrap gap-2 mt-2">
            {user.interests.slice(0, 3).map(tag => (
              <span key={tag} className="bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 px-3 py-1 rounded-full text-sm font-medium">{tag}</span>
            ))}
          </div>
        </div>
        
        {/* Actions */}
        <div className="mt-8 w-full">
            {isPaid && joynPayDetails ? (
                <button
                  onClick={(e) => { e.stopPropagation(); onJoinPaidDropIn(user); }}
                  disabled={isOffline}
                  className="w-full flex items-center justify-center gap-2 bg-teal-500 hover:bg-teal-600 text-white font-bold py-4 px-4 rounded-xl transition-all text-lg transform active:scale-95 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  Get Ticket - <PriceDisplay price={joynPayDetails.price} currency={joynPayDetails.currency} />
                </button>
            ) : (
                <button
                  onClick={() => onWaveRequest(user)}
                  disabled={isOffline}
                  className="w-full flex items-center justify-center gap-2 bg-[#FFD94C] hover:bg-amber-300 text-gray-800 font-bold py-4 px-4 rounded-xl transition-all text-lg transform active:scale-95 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  <span role="img" aria-label="wave">👋</span> Send a Wave
                </button>
            )}
        </div>
      </div>
    </Modal>
  );
};

export default DropInModal;
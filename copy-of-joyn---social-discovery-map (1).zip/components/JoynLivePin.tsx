import React from 'react';
import { JoynLiveUpdate } from '../types';
import { Icon } from './common/Icon';
import { MessageIcon } from './common/AppIcons';

interface JoynLivePinProps {
  liveUpdate: JoynLiveUpdate;
  onClick: () => void;
}

const JoynLivePin: React.FC<JoynLivePinProps> = ({ liveUpdate, onClick }) => {
  const hasReplies = liveUpdate.replies.length > 0;

  return (
    <div
      className="cursor-pointer group"
      onClick={onClick}
      title={`JoynLive: "${liveUpdate.content.substring(0, 30)}..."`}
    >
      <div className={`relative w-10 h-10 flex items-center justify-center rounded-full shadow-md transition-all group-hover:scale-110 group-hover:shadow-lg bg-purple-500`}>
        {hasReplies && <div className="absolute w-full h-full rounded-full bg-purple-400 animate-ping opacity-75" style={{animationDuration: '3s'}}></div>}
        <div className="absolute inset-0 bg-black/10 rounded-full"></div>
        <Icon className="relative w-5 h-5 text-white" strokeWidth="2">
          <MessageIcon />
        </Icon>
      </div>
    </div>
  );
};

export default JoynLivePin;
import React, { useState, useRef, useEffect, useCallback, useMemo, useLayoutEffect } from 'react';
import { JoynLiveUpdate, User, VibeTag } from '../../types';
import { MessageIcon } from '../common/AppIcons';
import { VIBE_TAGS, calculateDistance } from '../../constants';

const timeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 5) return "Just now";
    let interval = seconds / 31536000;
    if (interval > 1) return `${Math.floor(interval)}y`;
    const interval_mo = seconds / 2592000;
    if (interval_mo > 1) return `${Math.floor(interval_mo)}mo`;
    const interval_d = seconds / 86400;
    if (interval_d > 1) return `${Math.floor(interval_d)}d`;
    const interval_h = seconds / 3600;
    if (interval_h > 1) return `${Math.floor(interval_h)}h`;
    const interval_m = seconds / 60;
    if (interval_m > 1) return `${Math.floor(interval_m)}m`;
    return `${Math.floor(seconds)}s`;
};


const LiveStreamCard: React.FC<{ liveUpdate: JoynLiveUpdate; author?: User; distance: string | null, onReact: (emoji: string) => void, onClick: () => void }> = ({ liveUpdate, author, distance, onReact, onClick }) => {
    if (!author) return null;

    const vibeTags = author.pin?.vibeTagIds
        ?.map(id => VIBE_TAGS.find(tag => tag.id === id))
        .filter((tag): tag is VibeTag => !!tag) ?? [];

    return (
        <div
            onClick={onClick}
            className="bg-white dark:bg-gray-900 rounded-2xl shadow-sm overflow-hidden mb-3 group transition-all duration-300 border border-gray-200 dark:border-gray-800 cursor-pointer"
        >
            <div className="p-3 flex justify-between items-start gap-2">
                <div className="flex items-center gap-2 overflow-hidden">
                    <img src={author.avatarUrl} alt={author.alias} className="w-9 h-9 rounded-full flex-shrink-0" />
                    <div className="overflow-hidden">
                        <span className="text-sm font-semibold text-gray-800 dark:text-gray-200 truncate">{author.alias}</span>
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium truncate">
                           {distance ? `${distance} away` : 'Location private'} · {timeAgo(liveUpdate.timestamp)}
                        </p>
                    </div>
                </div>
                <button className="text-gray-400 p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 flex-shrink-0">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h.01M12 12h.01M19 12h.01"></path></svg>
                </button>
            </div>

            {vibeTags.length > 0 && (
                <div className="px-3 pb-2 flex flex-wrap gap-1.5">
                    {vibeTags.map(tag => (
                        <span key={tag.id} className={`px-2 py-0.5 rounded-full text-xs font-medium flex items-center gap-1.5 ${tag.color.bg} ${tag.color.text} dark:bg-opacity-20 dark:text-opacity-90`}>
                            {tag.emoji} {tag.name}
                        </span>
                    ))}
                </div>
            )}
            
            <div className="px-3 pb-3">
                <p className="text-gray-700 dark:text-gray-300 text-sm leading-snug">{liveUpdate.content}</p>
            </div>

            <div className="px-3 py-1.5 bg-gray-50 dark:bg-gray-800/50 flex items-center justify-between">
                <div className="text-xs text-gray-500 dark:text-gray-400 font-medium flex items-center gap-1.5">
                    <MessageIcon className="w-4 h-4" />
                    <span>{liveUpdate.replies.length > 0 ? `${liveUpdate.replies.length} ${liveUpdate.replies.length === 1 ? 'reply' : 'replies'}` : 'Leave a reply'}</span>
                </div>
                 <div className="flex gap-0">
                    {['👍', '💜', '😂', '🔥'].map(emoji => (
                        <button 
                            key={emoji}
                            onClick={(e) => { e.stopPropagation(); onReact(emoji); }}
                            className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 transition-all text-base transform hover:scale-125"
                            aria-label={`React with ${emoji}`}
                        >
                            {emoji}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};


export const JoynLiveStream: React.FC<{ liveUpdates: JoynLiveUpdate[], users: User[], currentUser: User, onLiveUpdateClick: (liveUpdate: JoynLiveUpdate) => void }> = ({ liveUpdates, users, currentUser, onLiveUpdateClick }) => {
    const contentRef = useRef<HTMLDivElement>(null);
    const [isInteracting, setIsInteracting] = useState(false);
    const [animationDuration, setAnimationDuration] = useState('60s');
    const [lastReaction, setLastReaction] = useState<{ emoji: string, id: number } | null>(null);

    const duplicatedUpdates = useMemo(() => {
        if (!liveUpdates || liveUpdates.length === 0) return [];
        let base = [...liveUpdates];
        // Ensure there's enough content to make scrolling seamless and avoid gaps
        while (base.length > 0 && base.length < 20) {
            base = [...base, ...liveUpdates];
        }
        return [...base, ...base];
    }, [liveUpdates]);

    useLayoutEffect(() => {
        if (contentRef.current) {
            const scrollHeight = contentRef.current.offsetHeight;
            // The content is duplicated, so we are scrolling half of the total height
            const halfHeight = scrollHeight / 2;
            const pixelsPerSecond = 40; // Adjust for desired speed
            const duration = halfHeight / pixelsPerSecond;
            if (duration > 0) {
                setAnimationDuration(`${duration}s`);
            }
        }
    }, [duplicatedUpdates]);

    const handleReaction = (emoji: string) => {
        setLastReaction({ emoji, id: Date.now() });
    };
    
    if (duplicatedUpdates.length === 0) {
        return (
            <div className="h-[500px] flex items-center justify-center bg-gray-50 dark:bg-gray-900/50 rounded-2xl">
                <p className="text-gray-500 dark:text-gray-400">No live updates right now.</p>
            </div>
        );
    }

    return (
        <div className="h-[500px] relative">
            <div
                className="h-full w-full overflow-hidden"
                aria-label="Live updates feed"
                onMouseEnter={() => setIsInteracting(true)}
                onMouseLeave={() => setIsInteracting(false)}
                onTouchStart={() => setIsInteracting(true)}
                onTouchEnd={() => setIsInteracting(false)}
            >
                <div
                    ref={contentRef}
                    className={`pr-1 scroll-up-infinite ${isInteracting ? 'animation-paused' : ''}`}
                    style={{ '--scroll-duration': animationDuration } as React.CSSProperties}
                >
                    {duplicatedUpdates.map((update, index) => {
                        const author = users.find(u => u.id === update.authorId);
                        const distance = (author?.location && currentUser.location)
                            ? `${calculateDistance(currentUser.location.lat, currentUser.location.lng, author.location.lat, author.location.lng).toFixed(1)} mi`
                            : null;

                        return (
                            <LiveStreamCard
                                key={`${update.id}-${index}`}
                                liveUpdate={update}
                                author={author}
                                distance={distance}
                                onReact={handleReaction}
                                onClick={() => onLiveUpdateClick(update)}
                            />
                        );
                    })}
                </div>
            </div>
            {lastReaction && (
                <div key={lastReaction.id} className="absolute bottom-4 right-4 text-4xl animate-reaction pointer-events-none z-10">
                    {lastReaction.emoji}
                </div>
            )}
            <div className="absolute top-0 left-0 w-full h-8 bg-gradient-to-b from-gray-100 dark:from-gray-950 to-transparent pointer-events-none"></div>
            <div className="absolute bottom-0 left-0 w-full h-8 bg-gradient-to-t from-gray-100 dark:from-gray-950 to-transparent pointer-events-none"></div>
        </div>
    );
};

import React from 'react';
import { DropInCircle, VibeTag, User } from '../../types';
import { Icon } from '../common/Icon';
import { BookmarkIcon } from '../common/AppIcons';
import PriceDisplay from '../joynpay/PriceDisplay';

interface ActivityCardProps {
    circle: DropInCircle;
    allVibeTags: VibeTag[];
    users: User[];
    isSaved: boolean;
    onToggleSave: () => void;
    onClick: () => void;
    index: number;
    isHostedByCurrentUser?: boolean;
}

const ActivityCard: React.FC<ActivityCardProps> = ({ circle, allVibeTags, users, isSaved, onToggleSave, onClick, index, isHostedByCurrentUser }) => {
    const host = users.find(u => u.id === circle.hostId);
    const circleVibeTags = circle.vibeTagIds?.map(id => allVibeTags.find(tag => tag.id === id)).filter(Boolean) as VibeTag[];

    const handleSaveClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onToggleSave();
    };

    return (
        <div 
            onClick={onClick} 
            className={`relative bg-white dark:bg-gray-900 rounded-2xl shadow-md cursor-pointer hover:shadow-lg transition-all transform hover:-translate-y-0.5 animate-list-item ${isHostedByCurrentUser ? 'border-2 border-purple-500 dark:border-purple-400' : ''}`}
            style={{ animationDelay: `${index * 50}ms` }}
        >
            <div className="p-4">
                <div className="flex justify-between items-start gap-4">
                    <div className="flex-grow">
                        <div className="flex items-center gap-2 mb-2">
                            {circle.isHot && <div className="w-2.5 h-2.5 bg-[#FF5C57] rounded-full animate-pulse"></div>}
                            <h3 className="font-bold text-lg text-gray-900 dark:text-gray-100 line-clamp-1">{circle.name}</h3>
                        </div>
                        {host && (
                            <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-3">
                                <img src={host.avatarUrl} alt={host.alias} className="w-6 h-6 rounded-full" />
                                <span>Hosted by {host.alias}</span>
                            </div>
                        )}
                    </div>
                    <div className="flex items-center gap-2">
                        {isHostedByCurrentUser && (
                            <div className="text-xs font-bold bg-purple-100 dark:bg-purple-900/50 text-purple-600 dark:text-purple-300 px-3 py-1.5 rounded-full">
                               Hosting
                            </div>
                        )}
                        {circle.joynPay?.isPaid && (
                            <div className="text-sm font-bold bg-teal-100 dark:bg-teal-900/50 text-teal-700 dark:text-teal-300 px-3 py-1.5 rounded-full">
                               <PriceDisplay price={circle.joynPay.price} currency={circle.joynPay.currency} />
                            </div>
                        )}
                        <button 
                            onClick={handleSaveClick}
                            className={`p-2 rounded-full transition-colors ${isSaved ? 'text-purple-500 bg-purple-100 dark:bg-purple-900/50' : 'text-gray-400 dark:text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                            aria-label={isSaved ? 'Unsave activity' : 'Save activity'}
                        >
                            <BookmarkIcon className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
                        </button>
                    </div>
                </div>

                {circleVibeTags.length > 0 && (
                    <div className="flex flex-wrap gap-2 border-t dark:border-gray-800 pt-3 mt-3">
                        {circleVibeTags.map(tag => (
                            <span key={tag.id} className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1.5 ${tag.color.bg} ${tag.color.text} dark:bg-opacity-20 dark:text-opacity-90`}>
                                {tag.emoji}
                                {tag.name}
                            </span>
                        ))}
                        <div className="flex-grow"></div>
                        <div className="text-sm font-semibold text-gray-500 dark:text-gray-400 px-3 py-1 rounded-full flex-shrink-0 flex items-center gap-2">
                            <Icon size={16}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></Icon>
                            <span>{circle.userIds.length} Joyners</span>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ActivityCard;

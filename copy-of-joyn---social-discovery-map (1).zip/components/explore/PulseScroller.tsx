import React from 'react';
import { DropInCircle, User } from '../../types';
import Pulse from './Pulse';

interface PulseScrollerProps {
  circles: DropInCircle[];
  users: User[];
  onPulseClick: (circle: DropInCircle) => void;
}

const PulseScroller: React.FC<PulseScrollerProps> = ({ circles, users, onPulseClick }) => {
  if (circles.length === 0) return null;

  return (
    <div className="flex space-x-4 overflow-x-auto -mx-4 px-4 pb-2 snap-x snap-mandatory no-scrollbar">
      {circles.map(circle => {
        const host = users.find(u => u.id === circle.hostId);
        return (
          <Pulse
            key={`pulse-${circle.id}`}
            circle={circle}
            host={host}
            onClick={() => onPulseClick(circle)}
          />
        );
      })}
      <style>{`.no-scrollbar::-webkit-scrollbar { display: none; } .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }`}</style>
    </div>
  );
};

export default PulseScroller;

import React from 'react';
import { GooglePlace, User } from '../../types';
import { Icon } from '../common/Icon';
import { calculateDistance } from '../../constants';

interface PlaceCardProps {
  place: GooglePlace;
  users: User[];
  onClick: () => void;
}

export const PlaceCard: React.FC<PlaceCardProps> = ({ place, users, onClick }) => {
  const photoUrl = place.photos?.[0]?.uri || `https://via.placeholder.com/200x200/cccccc/888888?text=${encodeURIComponent(place.displayName)}`;
  
  const placeLoc = place.location;
  if (!placeLoc) {
    return null; // Don't render card if there's no location
  }
  
  const nearbyJoyners = users.filter(user => 
    user.pin && user.location && calculateDistance(placeLoc.lat, placeLoc.lng, user.location.lat, user.location.lng) < 0.2 // within ~200m
  ).length;

  return (
    <div
      onClick={onClick}
      className="snap-start flex-shrink-0 w-64 bg-white dark:bg-gray-900 rounded-2xl shadow-md p-3 cursor-pointer hover:shadow-lg transition-all transform hover:-translate-y-0.5"
    >
      <div className="relative h-32 rounded-xl overflow-hidden mb-3">
        <img src={photoUrl} alt={place.displayName} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
        {place.rating && (
          <div className="absolute top-2 right-2 flex items-center gap-1 bg-black/50 backdrop-blur-sm text-white text-xs font-bold px-2 py-1 rounded-full">
            <Icon size={14} className="text-amber-300"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></Icon>
            <span>{place.rating.toFixed(1)}</span>
          </div>
        )}
        {nearbyJoyners > 0 && (
             <div className="absolute bottom-2 right-2 flex items-center gap-1.5 bg-[#7D4CDB]/80 backdrop-blur-sm text-white text-xs font-bold px-2 py-1 rounded-full">
                 <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                <span>{nearbyJoyners} Joyner{nearbyJoyners > 1 ? 's' : ''} nearby</span>
            </div>
        )}
      </div>
      <h3 className="font-bold text-gray-900 dark:text-gray-100 truncate">{place.displayName}</h3>
      <p className="text-sm text-gray-500 dark:text-gray-400 capitalize truncate">{place.types?.[0]?.replace(/_/g, ' ')}</p>
    </div>
  );
};
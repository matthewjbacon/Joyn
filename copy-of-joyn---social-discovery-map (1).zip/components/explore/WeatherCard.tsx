
import React, { useState, useEffect } from 'react';
import { WeatherData, WeatherCondition, fetchWeather } from '../../services/weatherService';
import { WeatherSunnyIcon, WeatherCloudyIcon, WeatherRainyIcon, WeatherPartlyCloudyIcon } from '../common/AppIcons';

const WeatherIcon: React.FC<{ condition: WeatherCondition, className?: string }> = ({ condition, className }) => {
    switch (condition) {
        case 'Sunny': return <WeatherSunnyIcon className={className} />;
        case 'Cloudy': return <WeatherCloudyIcon className={className} />;
        case 'Rainy': return <WeatherRainyIcon className={className} />;
        case 'Partly Cloudy': return <WeatherPartlyCloudyIcon className={className} />;
        default: return <WeatherSunnyIcon className={className} />;
    }
};

const WeatherCard: React.FC = () => {
    const [weather, setWeather] = useState<WeatherData | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadWeather = async () => {
            setIsLoading(true);
            try {
                const data = await fetchWeather();
                setWeather(data);
            } catch (error) {
                console.error("Failed to load weather data", error);
            } finally {
                setIsLoading(false);
            }
        };
        loadWeather();
    }, []);

    if (isLoading || !weather) {
        return (
            <div className="bg-gray-200 dark:bg-gray-800/50 p-2 rounded-2xl animate-pulse flex items-center gap-3">
                <div className="flex items-center gap-2 pl-2 pr-3 flex-shrink-0">
                    <div className="w-8 h-8 bg-gray-300 dark:bg-gray-700 rounded-full"></div>
                    <div className="h-6 w-12 bg-gray-300 dark:bg-gray-700 rounded"></div>
                </div>
                <div className="w-px h-10 bg-gray-300 dark:bg-gray-700"></div>
                <div className="flex items-center space-x-2 overflow-x-hidden">
                    {Array.from({ length: 4 }).map((_, i) => (
                        <div key={i} className="flex flex-col items-center gap-1 flex-shrink-0 w-14 p-1.5">
                            <div className="h-3 w-8 bg-gray-300 dark:bg-gray-700 rounded"></div>
                            <div className="w-6 h-6 bg-gray-300 dark:bg-gray-700 rounded-full"></div>
                            <div className="h-4 w-6 bg-gray-300 dark:bg-gray-700 rounded"></div>
                        </div>
                    ))}
                </div>
            </div>
        );
    }
    
    const { currentTemp, condition, hourly } = weather;

    return (
        <div className="bg-white/90 dark:bg-gray-800/90 backdrop-blur-md p-2 rounded-2xl shadow-md flex items-center gap-3 animate-fade-in">
            {/* Current Weather (Static Part) */}
            <div className="flex items-center gap-2 pl-2 pr-3 flex-shrink-0">
                <WeatherIcon condition={condition} className="w-8 h-8 text-gray-700 dark:text-gray-300" />
                <p className="text-2xl font-bold text-gray-800 dark:text-gray-200">{currentTemp}°</p>
            </div>
            
            {/* Divider */}
            <div className="w-px h-10 bg-gray-200 dark:bg-gray-700"></div>
        
            {/* Hourly Forecast (Scrollable Part) */}
            <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar">
                {hourly.slice(1).map((hour, index) => ( // Slicing to skip 'Now' which is represented by the static part
                    <div key={index} className="flex flex-col items-center gap-1 flex-shrink-0 text-center w-14 p-1.5 rounded-lg">
                        <p className="text-xs font-bold uppercase text-gray-500 dark:text-gray-400">{hour.time}</p>
                        <WeatherIcon condition={hour.condition} className="w-6 h-6 text-gray-600 dark:text-gray-400" />
                        <p className="font-bold text-gray-800 dark:text-gray-200">{hour.temp}°</p>
                    </div>
                ))}
            </div>
            <style>{`.no-scrollbar::-webkit-scrollbar { display: none; } .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }`}</style>
        </div>
    );
};

export default WeatherCard;


import React from 'react';
import Modal from '../common/Modal';
import { VibeTag } from '../../types';
import { JoynCoinIcon, CloseIcon } from '../common/AppIcons';

interface FilterModalProps {
  isOpen: boolean;
  onClose: () => void;
  filters: { price: 'all' | 'paid'; vibe: string | null };
  onFilterChange: (filters: { price: 'all' | 'paid'; vibe: string | null }) => void;
  allVibeTags: VibeTag[];
}

const FilterModal: React.FC<FilterModalProps> = ({ isOpen, onClose, filters, onFilterChange, allVibeTags }) => {

  const handlePriceChange = (price: 'all' | 'paid') => {
    onFilterChange({ ...filters, price });
  };

  const handleVibeChange = (tagId: string | null) => {
    onFilterChange({ ...filters, vibe: tagId });
  };
  
  const handleClearFilters = () => {
      onFilterChange({ price: 'all', vibe: null });
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
        <div className="flex flex-col text-gray-800 dark:text-gray-200">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Filters</h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"><CloseIcon /></button>
            </div>

            <div className="space-y-6">
                {/* Price Filter */}
                <div>
                    <h3 className="font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-sm mb-3">Price</h3>
                    <div className="bg-gray-100 dark:bg-gray-800 p-1 rounded-full flex items-center text-center">
                        <button onClick={() => handlePriceChange('all')} className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors ${filters.price === 'all' ? 'bg-white dark:bg-gray-700 shadow text-purple-600' : 'text-gray-600 dark:text-gray-300'}`}>All</button>
                        <button onClick={() => handlePriceChange('paid')} className={`flex-1 py-2 text-sm font-bold rounded-lg transition-colors flex items-center justify-center gap-1 ${filters.price === 'paid' ? 'bg-white dark:bg-gray-700 shadow text-purple-600' : 'text-gray-600 dark:text-gray-300'}`}>
                            <JoynCoinIcon className="w-4 h-4 text-teal-500" /> Paid
                        </button>
                    </div>
                </div>

                {/* Vibe Filter */}
                <div>
                    <h3 className="font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider text-sm mb-3">Vibes</h3>
                    <div className="flex flex-wrap gap-2">
                        <button
                            onClick={() => handleVibeChange(null)}
                            className={`px-4 py-2 rounded-full font-semibold border-2 transition-all ${!filters.vibe ? 'bg-purple-500 text-white border-transparent' : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-200 hover:border-gray-400 dark:hover:border-gray-500'}`}
                        >
                            All Vibes
                        </button>
                        {allVibeTags.map(tag => {
                            const isSelected = filters.vibe === tag.id;
                            return (
                                <button
                                    key={tag.id}
                                    onClick={() => handleVibeChange(tag.id)}
                                    className={`px-4 py-2 rounded-full font-semibold flex items-center gap-2 border-2 transition-all ${isSelected ? `${tag.color.bg} ${tag.color.text} border-current dark:bg-opacity-30 dark:text-opacity-90` : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-200 hover:border-gray-400 dark:hover:border-gray-500'}`}
                                >
                                    <span>{tag.emoji}</span>
                                    <span>{tag.name}</span>
                                </button>
                            );
                        })}
                    </div>
                </div>
            </div>

            <div className="mt-8 flex gap-3">
                 <button onClick={handleClearFilters} className="bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold py-4 rounded-xl flex-grow hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">
                    Clear
                 </button>
                 <button onClick={onClose} className="bg-[#7D4CDB] text-white font-bold py-4 rounded-xl flex-grow hover:bg-[#6c3ac0] transition-colors">
                    Show Results
                 </button>
            </div>
        </div>
    </Modal>
  );
};

export default FilterModal;

import React from 'react';
import { DropInCircle, User } from '../../types';

interface PulseProps {
  circle: DropInCircle;
  host?: User;
  onClick: () => void;
}

const Pulse: React.FC<PulseProps> = ({ circle, host, onClick }) => {
  return (
    <div onClick={onClick} className="flex-shrink-0 flex flex-col items-center gap-2 cursor-pointer group w-20">
      <div className="relative w-20 h-20">
        <div className="absolute inset-0 rounded-full p-0.5 bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 group-hover:animate-spin-slow transition-transform group-hover:scale-105">
          <div className="bg-white dark:bg-gray-900 h-full w-full rounded-full p-0.5">
            {circle.coverImageUrl ? (
              <img src={circle.coverImageUrl} alt={circle.name} className="w-full h-full object-cover rounded-full" />
            ) : (
              <div className="w-full h-full rounded-full bg-gray-200 dark:bg-gray-700"></div>
            )}
          </div>
        </div>
        {host && (
          <img src={host.avatarUrl} alt={host.alias} className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full border-4 border-white dark:border-gray-900"/>
        )}
      </div>
      <p className="text-xs font-semibold text-gray-700 dark:text-gray-300 truncate w-full text-center">{circle.name}</p>
    </div>
  );
};

export default Pulse;

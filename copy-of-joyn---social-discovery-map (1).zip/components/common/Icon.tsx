import React from 'react';

interface IconProps {
  children: React.ReactNode;
  className?: string;
  size?: number;
  viewBox?: string;
  strokeWidth?: number | string;
}

export const Icon: React.FC<IconProps & React.SVGAttributes<SVGSVGElement>> = ({
  children,
  className = 'w-6 h-6',
  size = 24,
  viewBox = '0 0 24 24',
  strokeWidth = "2",
  ...rest
}) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox={viewBox}
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...rest}
    >
      {children}
    </svg>
  );
};



import React from 'react';
import { Icon } from './Icon';

export const MapIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M1 6v16l7-4 8 4 7-4V2l-7 4-8-4-7 4z"/><path d="M8 2v16"/><path d="M16 6v16"/></Icon>
export const DiscoveryIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></Icon>
export const CirclesIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></Icon>
export const ProfileIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></Icon>
export const JoynPinIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></Icon>
export const JoynPlusIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M12 5v14M5 12h14" /></Icon>

export const PlusIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></Icon>
export const MinusIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><line x1="5" y1="12" x2="19" y2="12"></line></Icon>

export const ExplorerIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></Icon>
export const CreatorIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M15.09 16.5A5.002 5.002 0 0 1 8.5 22H7.5A4.5 4.5 0 0 1 3 17.5V11a9 9 0 0 1 18 0v6.5a4.5 4.5 0 0 1-4.5 4.5h-1a5.002 5.002 0 0 1-6.51-5.41"/><path d="M12 12a3 3 0 0 0 3-3V2.5A2.5 2.5 0 0 0 12.5 0h-1A2.5 2.5 0 0 0 9 2.5V9a3 3 0 0 0 3 3z"/></Icon>
export const ConnectorIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.72"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.72-1.72"/></Icon>
export const HelperIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><line x1="4.93" y1="4.93" x2="9.17" y2="9.17"/><line x1="14.83" y1="9.17" x2="19.07" y2="4.93"/><line x1="14.83" y1="14.83" x2="19.07" y2="19.07"/><line x1="4.93" y1="19.07" x2="9.17" y2="14.83"/></Icon>

export const SunIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m4.93 19.07 1.41-1.41"/><path d="m17.66 6.34 1.41-1.41"/></Icon>
export const MoonIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></Icon>

export const FoodIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M7 21h10" /><path d="M4 3h16l-2 12H6z" /><path d="M12 3v18" /></Icon>
export const CafeIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M10 21h4" /><path d="M12 18v3" /><path d="M8 8V4h8v4" /><path d="M4 8h16l-2 10H6Z" /></Icon>
export const ShoppingIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" /><path d="M3 6h18" /><path d="M16 10a4 4 0 0 1-8 0" /></Icon>
export const ArtIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></Icon>
export const OutdoorsIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="m8 3 4 8 5-5 5 15H2L8 3z" /></Icon>
export const BarIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M15 11h6" /><path d="M12 3v6" /><path d="M6.4 7.9 4.5 6" /><path d="M17.6 7.9 19.5 6" /><path d="M12 13h.01" /><path d="M22 13h-2" /><path d="M3 13H2" /><path d="M21 17H3" /></Icon>
export const AttractionIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M14.5 4h-9A2.5 2.5 0 0 0 3 6.5v9A2.5 2.5 0 0 0 5.5 18h9a2.5 2.5 0 0 0 2.5-2.5v-9A2.5 2.5 0 0 0 14.5 4z"/><circle cx="12" cy="11.5" r="3.5"/></Icon>
export const DefaultPlaceIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M16 22H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2zM6 18h12M6 12h12"/></Icon>

export const ChevronLeftIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M15 18l-6-6 6-6"></path></Icon>
export const CloseIcon: React.FC<{className?: string; size?: number}> = ({ className, size }) => <Icon className={className} size={size}><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></Icon>
export const SendIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M22 2L11 13"></path><path d="M22 2L15 22l-4-9-9-4 21-7z"></path></Icon>
export const MessageIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></Icon>
export const TrailIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M4 1L10 7L4 13L10 19"/></Icon>
export const InviteIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></Icon>
export const BlockIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></Icon>
export const ReportIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></Icon>
export const SearchIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="m21 21-6-6m2-5a7 7 0 1 1-14 0 7 7 0 0 1 14 0z"/></Icon>
export const GhostIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M20 21v-3.37a4.13 4.13 0 0 0-1.21-2.93l-1.6-1.6A10 10 0 0 0 12 4a10 10 0 0 0-5.18 9.1l-1.6 1.6A4.13 4.13 0 0 0 4 17.63V21l4-2 4 2 4-2 4 2z"/><path d="M9 12h.01M15 12h.01"/></Icon>
export const RecenterIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="3"/><path d="M22 12h-4"/><path d="M2 12H6"/><path d="M12 6V2"/><path d="M12 22v-4"/></Icon>
export const BookmarkIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></Icon>
export const VerifiedIcon: React.FC<React.SVGAttributes<SVGSVGElement>> = (props) => <Icon strokeWidth="2.5" {...props}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></Icon>
export const FilterIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></Icon>
export const InstantMeetIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></Icon>
export const TrashIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></Icon>
export const WeatherSunnyIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m4.93 19.07 1.41-1.41"/><path d="m17.66 6.34 1.41-1.41"/></Icon>
export const WeatherCloudyIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/></Icon>
export const WeatherRainyIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M16 13v8"/><path d="M12 12v8"/><path d="M8 13v8"/><path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"/></Icon>
export const WeatherPartlyCloudyIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M12 2v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="M20 12h2"/><path d="m17.66 17.66 1.41 1.41"/><path d="M17.5 22H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/></Icon>

// JoynPay Icons
export const JoynCoinIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><path d="M12 18V6"/></Icon>
export const WalletIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M20 12V8H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4Z"/><path d="M4 6v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M18 12a2 2 0 0 0-2-2h-8a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-4Z"/></Icon>
export const EarningsIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><line x1="12" x2="12" y1="1" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></Icon>
export const StripeIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className} viewBox="0 0 48 48"><path fill="#6772E5" d="M24,48c13.255,0,24-10.745,24-24S37.255,0,24,0S0,10.745,0,24S10.745,48,24,48z"/><path fill="#FFF" d="M16,12h16c2.209,0,4,1.791,4,4v8c0,2.209-1.791,4-4,4H16c-2.209,0-4-1.791-4-4v-8C12,13.791,13.791,12,16,12z"/><path fill="#6772E5" d="M12.933,31.067C12.933,31.067,12.933,31.067,12.933,31.067c0.26-0.129,0.513-0.27,0.76-0.426c0.559-0.355,1.09-0.758,1.596-1.213c0.746-0.67,1.355-1.473,1.833-2.399c0.418-0.812,0.71-1.696,0.877-2.639h-8v-3h12v3h-2.585c-0.121,0.729-0.33,1.423-0.627,2.081c-0.347,0.762-0.817,1.447-1.408,2.052c-0.617,0.63-1.332,1.156-2.14,1.573c-0.762,0.394-1.58,0.681-2.45,0.858L12.933,31.067z"/><path fill="#FFF" d="M29,18h-5v12h5c3.314,0,6-2.686,6-6S32.314,18,29,18z M29,26h-1v-4h1c1.105,0,2,0.895,2,2S30.105,26,29,26z"/></Icon>
export const SecurePaymentIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></Icon>

export const ShoutoutIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M2 9.5l4-3v11l-4-3v-5zM7 6.5v11L14.5 12 7 6.5zM22 10v4a2 2 0 0 1-2 2h-3l-2 2v-2H9.5a2.5 2.5 0 0 1 0-5H17a2 2 0 0 1 2-2h1a2 2 0 0 1 2 2z"/></Icon>
export const CheckIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className} strokeWidth="3"><path d="M20 6L9 17l-5-5"/></Icon>
export const CheckCheckIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className} strokeWidth="3"><path d="M20 6L9 17l-5-5"/><path d="M15 6l-9 9"/></Icon>
export const VoiceIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></Icon>
export const PlayIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><polygon points="5 3 19 12 5 21 5 3"/></Icon>

// New Icons from prompt
export const FireIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M10.64 5.5A4.5 4.5 0 0 1 9 10.45c0 3.03 2.15 5.56 4.69 6.45a4.5 4.5 0 0 1-1.38 3.1H9a7 7 0 1 1 7-7c0 1.25-.41 2.4-1.12 3.32a4.5 4.5 0 0 1-5.24 1.13c-1.48-.56-2.64-1.89-2.64-3.45a2.5 2.5 0 0 1 2.5-2.5c.34 0 .67.07.98.2Z"/></Icon>
export const TranslateIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M5 8h4m-2 2v10m0-10-3 3-3-3"/><path d="M10 12h10M10 16h10m-3-6 4-4 4 4"/><path d="M14 5v1"/></Icon>
export const LanguageIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/></Icon>
export const ShieldIcon: React.FC<{className?: string}> = ({ className }) => <Icon className={className}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></Icon>
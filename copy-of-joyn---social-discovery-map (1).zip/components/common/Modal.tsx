import React, { useEffect } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  variant?: 'bottom-sheet' | 'default';
  animationClass?: string;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, children, variant = 'default', animationClass = 'animate-slide-up-bounce' }) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="absolute inset-0 bg-black/30 dark:bg-black/50 backdrop-blur-sm z-60 flex justify-center items-end sm:items-center animate-fade-in"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div
        className={
          variant === 'default'
            ? `bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-t-3xl sm:rounded-2xl w-full max-w-md p-6 pt-4 shadow-2xl transform ${animationClass}`
            : `w-full max-w-2xl transform ${animationClass}` // No default styling for bottom-sheet
        }
        onClick={(e) => e.stopPropagation()}
      >
        {variant === 'default' && <div className="w-12 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-4 cursor-grab"></div>}
        {children}
      </div>
    </div>
  );
};

export default Modal;
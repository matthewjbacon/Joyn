

import { GoogleGenAI } from "@google/genai";
import { User, DropInCircle } from "../types";

// Per the guidelines, `process.env.API_KEY` is assumed to be configured and
// accessible in the execution environment. The previous check for `process`
// caused a `ReferenceError` in browser contexts, preventing the app from loading.
// This direct initialization relies on the environment to provide the key.
// A try-catch block is added for robustness in case the key is missing from the environment.
let ai: GoogleGenAI | null = null;
try {
  // The API key MUST be available in the execution environment.
  ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
} catch (error) {
  console.error("Failed to initialize GoogleGenAI. AI features will be disabled.", error);
  // The `ai` variable will remain null, and the functions below will gracefully fall back.
}

/**
 * Generates a friendly, actionable discovery suggestion for the user.
 */
export const generateDiscoverySuggestion = async (
  timeOfDay: 'morning' | 'afternoon' | 'evening',
  circles: DropInCircle[],
  users: User[]
): Promise<string> => {
  if (!ai) return "Explore what's happening around you!";

  let promptContext = `It's currently the ${timeOfDay}.`;

  if (circles.length > 0) {
    const circleNames = circles.map(c => `"${c.name}"`).join(', ');
    promptContext += ` Some nearby group activities are: ${circleNames}.`;
  }

  if (users.length > 0) {
    const userVibes = users.map(u => u.pin?.title ? `a user who is "${u.pin.title}"` : `a user who is available`);
    promptContext += ` Some nearby people are: ${userVibes.slice(0, 3).join(', ')}.`;
  }

  const prompt = `You are a friendly and enthusiastic AI guide for a social discovery app called Joyn. Your goal is to give a short, exciting, and actionable suggestion to the user. ${promptContext} Based on this, generate a single sentence (under 150 characters) suggesting what the user could do. Frame it as a friendly tip. Be creative and inspiring. For example: "It's a great ${timeOfDay} to join the '${circles[0]?.name || 'local vibe'}' or see who's out and about!" Do not use quotes in the final output.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.7,
        maxOutputTokens: 40,
        thinkingConfig: { thinkingBudget: 20 }
      },
    });
    return response.text.trim();
  } catch (error) {
    console.error("Failed to generate discovery suggestion with Gemini:", error);
    return "Explore the exciting things happening near you right now!";
  }
};


/**
 * Generates a friendly icebreaker message for a one-on-one chat.
 */
export const generateConversationStarter = async (
  currentUser: User,
  otherUser: User,
  locationName?: string,
  tone: 'playful' | 'curious' | 'bold' | 'default' = 'default'
): Promise<string> => {
  // If the AI client wasn't initialized, return a default value.
  if (!ai) return "Hey! What's up?";

  const sharedInterests = currentUser.interests.filter(interest => otherUser.interests.includes(interest));
  
  let context = `They are connecting near ${locationName || 'the city'}.`;
  if(sharedInterests.length > 0) {
      context += ` They share interests in: ${sharedInterests.join(', ')}.`;
  }
  
  let toneInstruction = '';
  switch (tone) {
    case 'playful':
      toneInstruction = 'Make it fun and witty.';
      break;
    case 'curious':
      toneInstruction = 'Make it inquisitive and thoughtful.';
      break;
    case 'bold':
      toneInstruction = 'Make it direct and confident.';
      break;
    default:
      toneInstruction = 'Make it friendly and casual.';
      break;
  }

  const prompt = `You are an AI for a social app called Joyn. Your voice is spontaneous and connection-forward. User "${currentUser.alias}" wants to start a chat with "${otherUser.alias}". ${context} Generate a friendly, open-ended icebreaker message (under 120 characters) from ${currentUser.alias} to ${otherUser.alias}. Make it sound natural and not like a robot. ${toneInstruction} Example: "Saw we're both into live music, catch any good shows lately?". Do not use quotes in the output.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
       config: {
        temperature: 0.8,
        maxOutputTokens: 30,
        thinkingConfig: { thinkingBudget: 15 }
      },
    });
    return response.text.trim();
  } catch (error) {
    console.error("Failed to generate conversation starter with Gemini:", error);
    return `Hey ${otherUser.alias}! 👋`;
  }
};

/**
 * Translates text to the specified target language.
 */
export const translateText = async (
  text: string,
  targetLanguage: 'en' | 'es'
): Promise<string> => {
  if (!ai) return `[Translation unavailable] ${text}`;

  const languageName = targetLanguage === 'en' ? 'English' : 'Spanish';
  const prompt = `Translate the following text to ${languageName}. Respond with only the translated text, without any additional comments or explanations.

Text to translate:
"${text}"`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.2,
      },
    });
    return response.text.trim();
  } catch (error) {
    console.error(`Failed to translate text to ${languageName}:`, error);
    return `[Translation failed] ${text}`;
  }
};
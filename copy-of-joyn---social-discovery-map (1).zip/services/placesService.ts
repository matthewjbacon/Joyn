import { GooglePlace } from '../types';

// Declare google object for TypeScript
declare global {
  interface Window {
    google: any;
  }
}

const CACHE_DURATION_MS = 5 * 60 * 1000; // 5 minutes

let cache: {
  data: GooglePlace[] | null;
  timestamp: number;
  location: { lat: number; lng: number } | null;
} = {
  data: null,
  timestamp: 0,
  location: null,
};

// Check if two locations are roughly the same to invalidate cache if user moves significantly
const isSameLocation = (
  loc1: { lat: number; lng: number },
  loc2: { lat: number; lng: number }
) => {
  const latDiff = Math.abs(loc1.lat - loc2.lat);
  const lngDiff = Math.abs(loc1.lng - loc2.lng);
  return latDiff < 0.01 && lngDiff < 0.01; // Approx 1km
};

export const fetchNearbyPlaces = async (
  location: { lat: number; lng: number }
): Promise<GooglePlace[]> => {
  // Check cache first
  if (
    cache.data &&
    cache.location &&
    isSameLocation(cache.location, location) &&
    Date.now() - cache.timestamp < CACHE_DURATION_MS
  ) {
    return Promise.resolve(cache.data);
  }

  if (!window.google || !window.google.maps || !window.google.maps.places || !window.google.maps.places.Place) {
    return Promise.reject(new Error('Google Places library not loaded.'));
  }

  const textQuery = 'popular places to hangout';

  const request = {
    textQuery,
    fields: ['id', 'displayName', 'location', 'rating', 'types', 'photos', 'formattedAddress', 'userRatingCount'],
    locationBias: new window.google.maps.Circle({ center: location, radius: 3200 }), // ~2 miles
    maxResultCount: 20,
  };

  try {
    const { places } = await window.google.maps.places.Place.searchByText(request);
    
    if (places) {
      const formattedPlaces: GooglePlace[] = places
        .filter((place: any) => place.location) // Ensure place has a location
        .map((place: any) => ({
          id: place.id,
          displayName: place.displayName,
          location: place.location?.toJSON(),
          rating: place.rating,
          types: place.types,
          photos: place.photos?.map((p: any) => ({ uri: p.getURI() })),
          formattedAddress: place.formattedAddress,
          userRatingCount: place.userRatingCount,
      }));
      
      cache = { data: formattedPlaces, timestamp: Date.now(), location: location };
      return formattedPlaces;
    }
    return [];
  } catch (error) {
    console.error('Google Places API error:', error);
    throw new Error(`Places service failed with status: ${error}`);
  }
};
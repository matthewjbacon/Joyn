
export type WeatherCondition = 'Sunny' | 'Partly Cloudy' | 'Cloudy' | 'Rainy';

export interface HourlyForecast {
    time: string; // e.g., '3PM'
    temp: number;
    condition: WeatherCondition;
}

export interface WeatherData {
    currentTemp: number;
    condition: WeatherCondition;
    summary: string;
    hourly: HourlyForecast[];
}

// Mock service to simulate fetching weather data
export const fetchWeather = (): Promise<WeatherData> => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({
                currentTemp: 72,
                condition: 'Partly Cloudy',
                summary: "A pleasant afternoon. Perfect for a walk or outdoor seating.",
                hourly: [
                    { time: 'Now', temp: 72, condition: 'Partly Cloudy' },
                    { time: '4PM', temp: 71, condition: 'Partly Cloudy' },
                    { time: '5PM', temp: 70, condition: 'Sunny' },
                    { time: '6PM', temp: 68, condition: 'Sunny' },
                    { time: '7PM', temp: 65, condition: 'Cloudy' },
                    { time: '8PM', temp: 62, condition: 'Cloudy' },
                ]
            });
        }, 800); // Simulate network delay
    });
};
